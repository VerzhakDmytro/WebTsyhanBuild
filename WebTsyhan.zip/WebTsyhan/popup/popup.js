const downloadedVersion = '1.0.13';
const serverIpPort = 'http://localhost:8000';
let backendIsStarted = false;

class Img {
    constructor(link) {
        this.selected = true;
        this.link = link;

        this.renderObj();
    }

    renderObj() {
        let imgContainer = document.getElementById('photoContainer');
        let imgDiv = document.createElement('div');
        let imgBorderDiv = document.createElement('div');
        let dragDiv = document.createElement('div');
        let dragLeft = document.createElement('div');
        let dragRight = document.createElement('div');
        let img = document.createElement('img');

        imgContainer.appendChild(imgDiv);
        imgDiv.appendChild(dragDiv);
        imgDiv.appendChild(imgBorderDiv);
        imgBorderDiv.appendChild(img);
        dragDiv.appendChild(dragLeft);
        dragDiv.appendChild(dragRight);

        imgDiv.classList.add('imageDiv');
        imgBorderDiv.classList.add('imgBorderDiv');
        if (this.selected) {
            imgDiv.classList.add('selected');
        }
        imgDiv.setAttribute('draggable', true);
        img.src = this.link;
        img.setAttribute('draggable', false);
        dragDiv.classList.add('dragContainer');

        imgDiv.onclick = () => {
            document.getElementById('mainStatus').innerText = 'ready';
            this.selected = !this.selected;
            if (this.selected) {
                imgDiv.classList.add('selected');
            } else {
                imgDiv.classList.remove('selected');
            }
        };

        imgDiv.ondragstart = () => {
            imgDiv.classList.add('onDrag');
            Img.dragItem = this;
        }

        imgDiv.ondragend = () => {
            imgDiv.classList.remove('onDrag');
            Img.moveImgCallback();
        }

        dragLeft.ondragenter = (e) => {
            if (Img.dragItem !== this) {
                imgBorderDiv.classList.add('moveRight');
                Img.dragDest.item = this;
                Img.dragDest.direction = 'l';
                e.stopImmediatePropagation();
            }
        }

        dragLeft.ondragleave = (e) => {
            imgBorderDiv.classList.remove('moveRight');
            e.stopImmediatePropagation();
        }

        dragRight.ondragenter = (e) => {
            if (Img.dragItem !== this) {
                imgBorderDiv.classList.add('moveLeft');
                Img.dragDest.item = this;
                Img.dragDest.direction = 'r';
                e.stopImmediatePropagation();
            }
        }

        dragRight.ondragleave = (e) => {
            imgBorderDiv.classList.remove('moveLeft');
            e.stopImmediatePropagation();
        }
    }

    static moveImgCallback = null;

    static dragItem = null;
    static dragDest = {
        item: null,
        direction: null
    };
}

let folderName;
let imgs = [];

document.getElementsByTagName('body')[0].ondragenter = () => {
    Img.dragDest.item = null;
    Img.dragDest.direction = null;
}

const removeAllImgs = () => {
    const childs = Array.from(document.getElementsByClassName('imageDiv'));
    childs.forEach(element => {
        element.remove();
    });
    imgs = [];
}

Img.moveImgCallback = () => {
    if (Img.dragDest.item !== null) {
        document.getElementById('mainStatus').innerText = 'ready';
        let newArr = [];
        imgs.forEach(img => {
            if (img !== Img.dragItem && img !== Img.dragDest.item) {
                newArr.push(img);
            } else if (img === Img.dragDest.item) {
                if (Img.dragDest.direction === 'l') {
                    newArr.push(Img.dragItem);
                    newArr.push(img);
                } else {
                    newArr.push(img);
                    newArr.push(Img.dragItem);
                }
            }
        });

        Img.dragDest.item = null;
        Img.dragDest.direction = null;

        removeAllImgs();

        imgs = newArr;
        imgs.forEach(element => {
            element.renderObj();
        });
    }
    Img.dragItem = null;
}

const parseImgs = () => {
    try {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            chrome.tabs.sendMessage(tabs[0].id, { action: "getImgs" }, (response) => {
                if (!chrome.runtime.lastError) {
                    document.getElementById('reloadAlert').classList.remove('visible');
                    if (response?.imgs?.length) {
                        response?.imgs.forEach(img => {
                            imgs.push(new Img(img));
                        });
                        document.getElementById('downloadButton').removeAttribute('disabled');
                        document.getElementById('mainStatus').innerText = 'ready';
                    }
                } else {
                    document.getElementById('reloadAlert').classList.add('visible');
                    document.getElementById('mainStatus').innerText = 'error';
                }
            });
        });
    } catch (e) {
        console.log(e);
    }
}

document.getElementById('refreshButton').onclick = () => {
    if (!backendIsStarted) return;
    removeAllImgs();
    parseImgs();
}

document.getElementById('downloadButton').onclick = async () => {
    try {
        document.getElementById('mainStatus').innerText = 'downloading';
        let downloadButton = document.getElementById('downloadButton');
        downloadButton.setAttribute('disabled', 'true');
        let nameInput = document.getElementById('folderNameInput').value.trim();
        let imgsToDownload = imgs.filter(img => img.selected).map(img => img.link);
        if (imgsToDownload.length < 1 || nameInput.length < 1) return;
        const res = await fetch(`${serverIpPort}/api/download`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify([{
                folderName: nameInput,
                urls: imgsToDownload
            }]),
        });
        downloadButton.removeAttribute('disabled');
        if (res.status !== 200) {
            console.log(res);
            document.getElementById('mainStatus').innerText = 'error';
        } else {
            document.getElementById('mainStatus').innerText = 'downloading complete';
        }
    } catch (e) {
        console.log(e);
        document.getElementById('mainStatus').innerText = 'error';
        downloadButton.removeAttribute('disabled');
    }
}

class Tab {
    constructor(tabEl, container, idx) {
        this.tabElement = tabEl;
        this.container = container;
        this.idx = idx;
        this.imgs = [];
    }

    setActive(active) {
        if (active) {
            this.tabElement.classList.add('active');
        } else {
            this.tabElement.classList.remove('active');
        }
    }
}

class TabController {
    constructor() {
        this.tabs = [];
        this.currentTabIdx = 0;
    }

    addTab(tabEl, container) {
        let tab = new Tab(tabEl, container, this.tabs.length);
        this.tabs.push(tab);
        tabEl.onclick = () => {
            this.tabs[this.currentTabIdx].setActive(false);
            this.currentTabIdx = tab.idx;
            tab.setActive(true);
        }
    }
}

let tabController = new TabController();
tabController.addTab(document.getElementById('tabLocal'), document.getElementById('photoContainer'));
tabController.addTab(document.getElementById('tabGlobal'), null);

const openPopup = (popupContainer) => {
    document.getElementById('mainContainer').classList.add('blured');
    popupContainer.classList.remove('hidden');
};

const closePopup = (popupContainer) => {
    document.getElementById('mainContainer').classList.remove('blured');
    popupContainer.classList.add('hidden');
};

const clearLocalStorage = async () => {
    await chrome.storage.local.remove(['updates']);
    await chrome.storage.local.remove(['lastUpdateCheck']);
}

const checkUpdates = async () => {
    try {
        let res = await fetch(`${serverIpPort}/api/update`, { cache: 'no-store' });
        if (res.status !== 200) {
            console.log(res);
            await clearLocalStorage();
        }
        let updatesJson = await res.json();
        await chrome.storage.local.set({ updates: updatesJson });
        await chrome.storage.local.set({ lastUpdateCheck: Date.now() });
    } catch (e) {
        console.log(e);
        await clearLocalStorage();
    }
}

const getAvailableVersions = async () => {
    const availVersions = await chrome.storage.local.get(['updates']);
    const lastTime = await chrome.storage.local.get(['lastUpdateCheck']);
    if (availVersions.updates === undefined ||
        lastTime.lastUpdateCheck === undefined ||
        Math.abs(Date.now() - new Date(lastTime.lastUpdateCheck)) > 1000 * 60 * 30) {
        await checkUpdates();
        return (await chrome.storage.local.get(['updates'])).updates;
    }
    return availVersions.updates;
}

let toUpdate = {
    webTsyhan: false,
    tsyhan: false
}

const getTsyhanVersion = async () => {
    try {
        let res = await fetch(`${serverIpPort}/api/version`, { cache: 'no-store' });
        if (res.status !== 200) {
            return null;
        }
        let json = await res.json();
        return json.tsyhanCurrVer;
    } catch (e) {
        console.log(e);
        return null;
    }
}

const setUpdateState = async () => {
    if (!backendIsStarted) return;
    const updates = await getAvailableVersions();

    let openUpdateButton = document.getElementById('openUpdateButton');
    let webTsyhanCurrVer = document.getElementById('webTsyhanCurrVer');
    let webTsyhanAvailVer = document.getElementById('webTsyhanAvailVer');
    let tsyhanCurrVer = document.getElementById('tsyhanCurrVer');
    let tsyhanAvailVer = document.getElementById('tsyhanAvailVer');
    let updateButton = document.getElementById('updateButton');

    updateButton.setAttribute('disabled', 'true');
    webTsyhanCurrVer.textContent = chrome.runtime.getManifest().version;

    if (updates === undefined) {
        webTsyhanAvailVer.textContent = webTsyhanCurrVer.textContent;
        tsyhanCurrVer.textContent = 'Unknown';
        tsyhanAvailVer.textContent = tsyhanCurrVer.textContent;
    } else {
        webTsyhanAvailVer.textContent = updates.webTsyhan;
        tsyhanCurrVer.textContent = await getTsyhanVersion();
        tsyhanAvailVer.textContent = updates.tsyhan;
    }

    if (webTsyhanCurrVer.textContent !== webTsyhanAvailVer.textContent ||
        tsyhanCurrVer.textContent !== tsyhanAvailVer.textContent
    ) {
        openUpdateButton.classList.add('available');
        document.getElementById('updateStatus').innerText = 'ready to update';
    } else {
        openUpdateButton.classList.remove('available');
        document.getElementById('updateStatus').innerText = 'updated';
    }

    if (webTsyhanCurrVer.textContent !== webTsyhanAvailVer.textContent) {
        webTsyhanAvailVer.parentNode.style.display = 'initial';

        toUpdate.webTsyhan = true;
        if (downloadedVersion !== webTsyhanAvailVer.textContent) {
            updateButton.removeAttribute('disabled');
        }
    } else {
        webTsyhanAvailVer.parentNode.style.display = 'none';

        toUpdate.webTsyhan = false;
    }
    if (tsyhanCurrVer.textContent !== tsyhanAvailVer.textContent) {
        tsyhanAvailVer.parentNode.style.display = 'initial';
        updateButton.removeAttribute('disabled');
        toUpdate.tsyhan = true;
    } else {
        tsyhanAvailVer.parentNode.style.display = 'none';
        toUpdate.tsyhan = false;
    }
};

const checkBackendAvailability = async () => {
    try {
        let res = await fetch(`${serverIpPort}/api/available`);
        if (res.status !== 200) {
            console.log(res);
            document.getElementById('startBackendAlert').classList.add('visible');
            document.getElementById('mainStatus').innerText = 'error';
            removeAllImgs();
        } else {
            backendIsStarted = true;
            parseImgs();
            setUpdateState();
        }
    } catch (e) {
        console.log(e);
        document.getElementById('startBackendAlert').classList.add('visible');
        document.getElementById('mainStatus').innerText = 'error';
        removeAllImgs();
    }
}
checkBackendAvailability();

const openExtensionsPage = () => {
    chrome.tabs.create({ url: 'chrome://extensions/' });
}

if (chrome.runtime.getManifest().version !== downloadedVersion) {
    openExtensionsPage();
}

document.getElementById('openUpdateButton').onclick = async () => {
    try {
        if (!backendIsStarted) return;
        openPopup(document.getElementById('updateContainer'));
        setUpdateState();
    } catch (e) {
        console.log(e);
    }
};

document.getElementById('checkUpdateButton').onclick = async () => {
    await checkUpdates();
    setUpdateState();
}

document.getElementById('updateButton').onclick = async () => {
    try {
        if (!backendIsStarted) return;
        updateButton.setAttribute('disabled', 'true');
        document.getElementById('updateStatus').innerText = 'updating';
        let res = await fetch(`${serverIpPort}/api/update`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(toUpdate)
        });
        if (res.status == 200) {
            if (toUpdate.webTsyhan) {
                openExtensionsPage();
            }
            toUpdate.tsyhan = false;
            toUpdate.webTsyhan = false;
            setTimeout(setUpdateState, 1000);
        } else {
            console.log(res);
            document.getElementById('updateStatus').innerText = 'error';
        }
    } catch (e) {
        console.log(e);
        document.getElementById('updateStatus').innerText = 'error';
    }
}

document.getElementById('closeUpdatePopupButton').onclick = () => {
    closePopup(document.getElementById('updateContainer'));
};

document.getElementById('settingsButton').onclick = async () => {
    try {
        if (!backendIsStarted) return;
        document.getElementById('settingSaveError').style.display = 'none';
        let settingsContainer = document.getElementById('settingsContainer');
        openPopup(settingsContainer);
        let res = await fetch(`${serverIpPort}/api/config`, { cache: 'no-store' });
        if (res.status !== 200) {
            console.log(res);
            closePopup(settingsContainer);
        }
        let json = await res.json();
        if (json.path !== undefined) {
            document.getElementById('pathInput').value = json.path;
        } else {
            document.getElementById('pathInput').value = 'C:\\photo';
        }
        if (json.trimmerWithBorder !== undefined) {
            document.getElementById('withBorderCheckbox').checked = json.trimmerWithBorder === 'true' ? true : false;
        } else {
            document.getElementById('withBorderCheckbox').checked = true;
        }
        if (json.trimmerWhiteBorderSize !== undefined) {
            document.getElementById('whiteBorderSizeInput').value = json.trimmerWhiteBorderSize;
        } else {
            document.getElementById('whiteBorderSizeInput').value = '10';
        }
    } catch (e) {
        console.log(e);
        closePopup(settingsContainer);
    }
}

document.getElementById('closeSettingsButton').onclick = () => {
    closePopup(document.getElementById('settingsContainer'));
}

document.getElementById('whiteBorderSizeInput').oninput = (ev) => {
    try {
        const value = Number.parseInt(ev.target.value);
        if (value < 0) {
            ev.target.value = '0';
        } else if (value > 999) {
            ev.target.value = '999';
        }
    } catch (e) {
        ev.target.value = '0';
    }
}

document.getElementById('configSaveButton').onclick = async () => {
    document.getElementById('settingSaveError').style.display = 'none';
    try {
        const res = await fetch(`${serverIpPort}/api/config`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                path: document.getElementById('pathInput').value,
                trimmerWithBorder: document.getElementById('withBorderCheckbox').checked.toString(),
                trimmerWhiteBorderSize: document.getElementById('whiteBorderSizeInput').value
            }),
        });
    } catch (e) {
        console.log(e);
        document.getElementById('settingSaveError').style.display = 'inline';
    }
}

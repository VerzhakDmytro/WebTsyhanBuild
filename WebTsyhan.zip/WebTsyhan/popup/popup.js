const downloadedVersion = '1.1.110';
const serverIpPort = 'http://localhost:8000';
let backendIsStarted = false;

// document.getElementById('reloadExtButton').onclick = () => {
//     chrome.runtime.reload();
// }

const saveCurrentTabState = async () => {
    let activeTab = tabController.getActiveTab();
    if (activeTab.idx === 0) {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            const response = await chrome.tabs.sendMessage(
                tab.id,
                {
                    action: "setState",
                    state: activeTab.imgs.map(el => { return { link: el.link, selected: el.selected } })
                }
            );
        } catch (e) {
            console.log(e);
        }
    } else if (activeTab.idx === 1) {
        await setStorageImages(activeTab.imgs.map(el => { return { link: el.link, selected: el.selected } }));
    }
}

class Img {
    constructor(link, container, selected = true) {
        this.selected = selected;
        this.link = link;

        this.renderObj(container);
    }

    async toggleSelected() {
        document.getElementById('mainStatus').innerText = 'ready';
        this.selected = !this.selected;
        if (this.selected) {
            this.imgDiv.classList.add('selected');
        } else {
            this.imgDiv.classList.remove('selected');
        }
        await saveCurrentTabState();
    }

    renderObj(container) {
        let imgDiv = document.createElement('div');
        let imgBorderDiv = document.createElement('div');
        let dragDiv = document.createElement('div');
        let dragLeft = document.createElement('div');
        let dragRight = document.createElement('div');
        let img = document.createElement('img');

        this.imgDiv = imgDiv

        container.appendChild(imgDiv);
        imgDiv.appendChild(dragDiv);
        imgDiv.appendChild(imgBorderDiv);
        imgBorderDiv.appendChild(img);
        dragDiv.appendChild(dragLeft);
        dragDiv.appendChild(dragRight);

        imgDiv.classList.add('imageDiv');
        imgBorderDiv.classList.add('imgBorderDiv');
        if (this.selected) {
            imgDiv.classList.add('selected');
        }
        imgDiv.setAttribute('draggable', true);
        img.src = this.link;
        img.setAttribute('draggable', false);
        dragDiv.classList.add('dragContainer');

        imgDiv.onclick = () => {
            this.toggleSelected();
        };

        imgDiv.ondragstart = () => {
            imgDiv.classList.add('onDrag');
            Img.dragItem = this;
        }

        imgDiv.ondragend = () => {
            imgDiv.classList.remove('onDrag');
            Img.moveImgCallback();
        }

        dragLeft.ondragenter = (e) => {
            if (Img.dragItem !== this) {
                imgBorderDiv.classList.add('moveRight');
                Img.dragDest.item = this;
                Img.dragDest.direction = 'l';
                e.stopImmediatePropagation();
            }
        }

        dragLeft.ondragleave = (e) => {
            imgBorderDiv.classList.remove('moveRight');
            e.stopImmediatePropagation();
        }

        dragRight.ondragenter = (e) => {
            if (Img.dragItem !== this) {
                imgBorderDiv.classList.add('moveLeft');
                Img.dragDest.item = this;
                Img.dragDest.direction = 'r';
                e.stopImmediatePropagation();
            }
        }

        dragRight.ondragleave = (e) => {
            imgBorderDiv.classList.remove('moveLeft');
            e.stopImmediatePropagation();
        }
    }

    static moveImgCallback = null;

    static dragItem = null;
    static dragDest = {
        item: null,
        direction: null
    };
}

let folderName;

document.getElementsByTagName('body')[0].ondragenter = () => {
    Img.dragDest.item = null;
    Img.dragDest.direction = null;
    moveToStorage = false;
}

const setStorageImages = async (imgs) => {
    await chrome.storage.local.set({ storageImages: imgs });
}

const getStorageImages = async () => {
    const imgs = await chrome.storage.local.get(['storageImages']);
    if (imgs.storageImages === undefined) {
        await setStorageImages([]);
        return [];
    }
    if (imgs.storageImages.length > 0 && imgs.storageImages[0].selected === undefined) {
        await setStorageImages([]);
        return [];
    }
    return imgs.storageImages;
}

class Tab {
    constructor(tabEl, tabButtons, container, idx) {
        this.tabElement = tabEl;
        this.tabButtons = tabButtons;
        this.container = container;
        this.idx = idx;
        this.imgs = [];
    }

    setActive(active) {
        if (active) {
            this.tabElement.classList.add('active');
            this.tabButtons.classList.add('active');
            this.container.classList.add('active');
        } else {
            this.tabElement.classList.remove('active');
            this.tabButtons.classList.remove('active');
            this.container.classList.remove('active');
        }
    }

    addImage(imgLink, selected = true) {
        let img = new Img(imgLink, this.container, selected)
        this.imgs.push(img);
    }

    renderImgs() {
        this.imgs.forEach(element => {
            element.renderObj(this.container);
        });
    }

    removeAllImgs() {
        const childs = Array.from(this.container.getElementsByClassName('imageDiv'));
        childs.forEach(element => {
            element.remove();
        });
        this.imgs = [];
    }
}

class TabController {
    constructor() {
        this.tabs = [];
        this.currentTabIdx = 0;
    }

    addTab(tabEl, tabButtons, container) {
        let tab = new Tab(tabEl, tabButtons, container, this.tabs.length);
        this.tabs.push(tab);
        tabEl.onclick = () => {
            this.setActiveTab(tab.idx);
        }
    }

    getActiveTab() {
        return this.tabs[this.currentTabIdx];
    }

    setActiveTab(idx) {
        this.tabs[this.currentTabIdx].setActive(false);
        this.currentTabIdx = idx;
        this.tabs[this.currentTabIdx].setActive(true);
    }
}

let tabController = new TabController();
let tabLocal = document.getElementById('tabLocal');
let tabGlobal = document.getElementById('tabGlobal');
tabController.addTab(tabLocal, document.getElementById('tabLocalButtons'), document.getElementById('localPhotoContainer'));
tabController.addTab(tabGlobal, document.getElementById('tabGlobalButtons'), document.getElementById('storagePhotoContainer'));

tabGlobal.ondragenter = (e) => {
    if (tabController.currentTabIdx !== 1) {
        tabGlobal.classList.add('onDrag');
        moveToStorage = true;
        Img.dragDest.item = null;
        Img.dragDest.direction = null;
        e.stopImmediatePropagation();
    }
}
tabGlobal.ondragleave = (e) => {
    if (tabController.currentTabIdx !== 1) {
        tabGlobal.classList.remove('onDrag');
        e.stopImmediatePropagation();
    }
}

let moveToStorage = false;

const moveToStorageFunc = async (img) => {
    let alreadyExist = false;
    let tabGlobal = tabController.tabs[1];
    for (let i = 0; i < tabGlobal.imgs.length; i++) {
        if (tabGlobal.imgs[i].link === img) {
            alreadyExist = true;
            break;
        }
    }
    if (!alreadyExist) {
        tabGlobal.addImage(img);
        await setStorageImages(tabGlobal.imgs.map(el => { return { link: el.link, selected: el.selected } }));
    }
}

Img.moveImgCallback = async () => {
    if (Img.dragDest.item !== null) {
        document.getElementById('mainStatus').innerText = 'ready';
        let activeTab = tabController.getActiveTab();
        let newArr = [];
        activeTab.imgs.forEach(img => {
            if (img !== Img.dragItem && img !== Img.dragDest.item) {
                newArr.push(img);
            } else if (img === Img.dragDest.item) {
                if (Img.dragDest.direction === 'l') {
                    newArr.push(Img.dragItem);
                    newArr.push(img);
                } else {
                    newArr.push(img);
                    newArr.push(Img.dragItem);
                }
            }
        });

        Img.dragDest.item = null;
        Img.dragDest.direction = null;

        activeTab.removeAllImgs();

        activeTab.imgs = newArr;
        activeTab.renderImgs();
        await saveCurrentTabState();
    } else if (moveToStorage) {
        moveToStorageFunc(Img.dragItem.link);
    }
    Img.dragItem = null;
}

const parseImgs = async (forceParse = false) => {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        const stateResponse = await chrome.tabs.sendMessage(tab.id, { action: "getState" });
        if (!forceParse && stateResponse?.state?.length) {
            let pageTab = tabController.tabs[0];
            stateResponse.state.forEach(el => pageTab.addImage(el.link, el.selected));
        } else {
            const parseResponse = await chrome.tabs.sendMessage(tab.id, { action: "getImgs" });
            if (parseResponse === undefined) throw new Error('This page is not supported');
            if (parseResponse?.imgs?.length) {
                parseResponse?.imgs.forEach(img => {
                    tabController.tabs[0].addImage(img);
                });
            }
            await saveCurrentTabState();
            document.getElementById('reloadAlert').classList.remove('visible');
        }
        document.getElementById('downloadButton').innerText = 'Download';
        document.getElementById('tabContainer').classList.remove('disabled');
        document.getElementById('mainStatus').innerText = 'ready';
    } catch (e) {
        console.log(e);
        document.getElementById('downloadButton').innerText = 'Create Folder';
        document.getElementById('reloadAlert').classList.add('visible');
        document.getElementById('mainStatus').innerText = 'error';
        document.getElementById('tabContainer').classList.add('disabled');
    }
}

const renderStorageImgs = async () => {
    const storageImgs = await getStorageImages();
    let storageTab = tabController.tabs[1];
    storageImgs.forEach(el => storageTab.addImage(el.link, el.selected));
}

renderStorageImgs();

const clearStorageImgs = async () => {
    tabController.tabs[1].removeAllImgs();
    await setStorageImages([]);
}

document.getElementById('buttonClearAll').onclick = async () => {
    await clearStorageImgs();
}

document.getElementById('buttonMoveAllToStorage').onclick = async () => {
    tabController.tabs[0].imgs.forEach(el => moveToStorageFunc(el.link));
}

document.getElementById('buttonMoveSelectedToStorage').onclick = async () => {
    tabController.tabs[0].imgs.filter(el => el.selected).forEach(el => moveToStorageFunc(el.link));
}

document.getElementById('refreshButton').onclick = () => {
    if (!backendIsStarted) return;
    tabController.tabs[0].removeAllImgs();
    parseImgs(true);
}

const saveSettingsToLocalStorage = async () => {
    await chrome.storage.local.set({
        settings: {
            convertToJPG: document.getElementById('convertToJPG').checked
        }
    });
}

const setSettingsFromLocalStorage = async () => {
    const obj = await chrome.storage.local.get(['settings']);
    if (obj.settings === undefined) {
        await saveSettingsToLocalStorage();
    } else {
        document.getElementById('convertToJPG').checked = obj.settings.convertToJPG;
    }
}

setSettingsFromLocalStorage();

document.getElementById('convertToJPG').oninput = async () => {
    await saveSettingsToLocalStorage();
}

const downloadImages = async () => {
    try {
        let nameInput = document.getElementById('folderNameInput').value.trim();
        let imgsToDownload = tabController.getActiveTab().imgs.filter(img => img.selected).map(img => img.link);
        if (nameInput.length < 1) return;
        document.getElementById('mainStatus').innerText = 'downloading';
        let downloadButton = document.getElementById('downloadButton');
        downloadButton.setAttribute('disabled', 'true');
        const convertToJPG = document.getElementById('convertToJPG').checked;
        const res = await fetch(`${serverIpPort}/api/download`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify([{
                folderName: nameInput,
                urls: imgsToDownload.map(el => { return { url: el, convert: convertToJPG } })
            }]),
        });
        downloadButton.removeAttribute('disabled');
        if (res.status !== 200) {
            console.log(res);
            document.getElementById('mainStatus').innerText = 'error';
        } else {
            if (imgsToDownload.length > 0) {
                document.getElementById('mainStatus').innerText = 'downloading complete';
            } else {
                document.getElementById('mainStatus').innerText = 'creating complete';
            }
            await clearStorageImgs();
        }
    } catch (e) {
        console.log(e);
        document.getElementById('mainStatus').innerText = 'error';
        downloadButton.removeAttribute('disabled');
    }
}

document.getElementById('downloadButton').onclick = async () => {
    await downloadImages();
}

document.getElementById('folderNameInput').onkeydown = async (e) => {
    if (e.key === 'Enter') {
        await downloadImages();
    }
}

document.getElementById('toggleSelectedButton').onclick = () => {
    tabController.getActiveTab().imgs.forEach(img => img.toggleSelected());
}

const openPopup = (popupContainer) => {
    document.getElementById('mainContainer').classList.add('blured');
    popupContainer.classList.remove('hidden');
};

const closePopup = (popupContainer) => {
    document.getElementById('mainContainer').classList.remove('blured');
    popupContainer.classList.add('hidden');
};

const clearLocalStorage = async () => {
    await chrome.storage.local.remove(['updates']);
    await chrome.storage.local.remove(['lastUpdateCheck']);
}

const checkUpdates = async () => {
    try {
        let res = await fetch(`${serverIpPort}/api/update`, { cache: 'no-store' });
        if (res.status !== 200) {
            console.log(res);
            await clearLocalStorage();
        }
        let updatesJson = await res.json();
        await chrome.storage.local.set({ updates: updatesJson });
        await chrome.storage.local.set({ lastUpdateCheck: Date.now() });
    } catch (e) {
        console.log(e);
        await clearLocalStorage();
    }
}

const getAvailableVersions = async () => {
    const availVersions = await chrome.storage.local.get(['updates']);
    const lastTime = await chrome.storage.local.get(['lastUpdateCheck']);
    if (availVersions.updates === undefined ||
        lastTime.lastUpdateCheck === undefined ||
        Math.abs(Date.now() - new Date(lastTime.lastUpdateCheck)) > 1000 * 60 * 30) {
        await checkUpdates();
        return (await chrome.storage.local.get(['updates'])).updates;
    }
    return availVersions.updates;
}

let toUpdate = {
    webTsyhan: false,
    tsyhan: false
}

const getTsyhanVersion = async () => {
    try {
        let res = await fetch(`${serverIpPort}/api/version`, { cache: 'no-store' });
        if (res.status !== 200) {
            return null;
        }
        let json = await res.json();
        return json.tsyhanCurrVer;
    } catch (e) {
        console.log(e);
        return null;
    }
}

const setUpdateState = async () => {
    if (!backendIsStarted) return;
    const updates = await getAvailableVersions();

    let openUpdateButton = document.getElementById('openUpdateButton');
    let webTsyhanCurrVer = document.getElementById('webTsyhanCurrVer');
    let webTsyhanAvailVer = document.getElementById('webTsyhanAvailVer');
    let tsyhanCurrVer = document.getElementById('tsyhanCurrVer');
    let tsyhanAvailVer = document.getElementById('tsyhanAvailVer');
    let updateButton = document.getElementById('updateButton');

    updateButton.setAttribute('disabled', 'true');
    webTsyhanCurrVer.textContent = chrome.runtime.getManifest().version;

    if (updates === undefined) {
        webTsyhanAvailVer.textContent = webTsyhanCurrVer.textContent;
        tsyhanCurrVer.textContent = 'Unknown';
        tsyhanAvailVer.textContent = tsyhanCurrVer.textContent;
    } else {
        webTsyhanAvailVer.textContent = updates.webTsyhan;
        tsyhanCurrVer.textContent = await getTsyhanVersion();
        tsyhanAvailVer.textContent = updates.tsyhan;
    }

    if (webTsyhanCurrVer.textContent !== webTsyhanAvailVer.textContent ||
        tsyhanCurrVer.textContent !== tsyhanAvailVer.textContent
    ) {
        openUpdateButton.classList.add('available');
        document.getElementById('updateStatus').innerText = 'ready to update';
    } else {
        openUpdateButton.classList.remove('available');
        document.getElementById('updateStatus').innerText = 'updated';
    }

    if (webTsyhanCurrVer.textContent !== webTsyhanAvailVer.textContent) {
        webTsyhanAvailVer.parentNode.style.display = 'initial';

        toUpdate.webTsyhan = true;
        if (downloadedVersion !== webTsyhanAvailVer.textContent) {
            updateButton.removeAttribute('disabled');
        }
    } else {
        webTsyhanAvailVer.parentNode.style.display = 'none';

        toUpdate.webTsyhan = false;
    }
    if (tsyhanCurrVer.textContent !== tsyhanAvailVer.textContent) {
        tsyhanAvailVer.parentNode.style.display = 'initial';
        updateButton.removeAttribute('disabled');
        toUpdate.tsyhan = true;
    } else {
        tsyhanAvailVer.parentNode.style.display = 'none';
        toUpdate.tsyhan = false;
    }
};

const checkBackendAvailability = async () => {
    try {
        let res = await fetch(`${serverIpPort}/api/available`);
        if (res.status !== 200) {
            console.log(res);
            document.getElementById('startBackendAlert').classList.add('visible');
            document.getElementById('mainStatus').innerText = 'error';
            tabController.getActiveTab().removeAllImgs();
        } else {
            backendIsStarted = true;
            parseImgs();
            setUpdateState();
        }
    } catch (e) {
        console.log(e);
        document.getElementById('startBackendAlert').classList.add('visible');
        document.getElementById('mainStatus').innerText = 'error';
        tabController.getActiveTab().removeAllImgs();
    }
}
checkBackendAvailability();

const openExtensionsPage = () => {
    chrome.tabs.create({ url: 'chrome://extensions/' });
}

if (chrome.runtime.getManifest().version !== downloadedVersion) {
    openExtensionsPage();
}

document.getElementById('openUpdateButton').onclick = async () => {
    try {
        if (!backendIsStarted) return;
        openPopup(document.getElementById('updateContainer'));
        setUpdateState();
    } catch (e) {
        console.log(e);
    }
};

document.getElementById('checkUpdateButton').onclick = async () => {
    await checkUpdates();
    setUpdateState();
}

document.getElementById('updateButton').onclick = async () => {
    try {
        if (!backendIsStarted) return;
        updateButton.setAttribute('disabled', 'true');
        document.getElementById('updateStatus').innerText = 'updating';
        let res = await fetch(`${serverIpPort}/api/update`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(toUpdate)
        });
        if (res.status == 200) {
            if (toUpdate.webTsyhan) {
                openExtensionsPage();
            }
            toUpdate.tsyhan = false;
            toUpdate.webTsyhan = false;
            setTimeout(setUpdateState, 1000);
        } else {
            console.log(res);
            document.getElementById('updateStatus').innerText = 'error';
        }
    } catch (e) {
        console.log(e);
        document.getElementById('updateStatus').innerText = 'error';
    }
}

document.getElementById('closeUpdatePopupButton').onclick = () => {
    closePopup(document.getElementById('updateContainer'));
};

document.getElementById('settingsButton').onclick = async () => {
    try {
        if (!backendIsStarted) return;
        document.getElementById('settingSaveError').style.display = 'none';
        let settingsContainer = document.getElementById('settingsContainer');
        openPopup(settingsContainer);
        let res = await fetch(`${serverIpPort}/api/config`, { cache: 'no-store' });
        if (res.status !== 200) {
            console.log(res);
            closePopup(settingsContainer);
        }
        let json = await res.json();
        if (json.path !== undefined) {
            document.getElementById('pathInput').value = json.path;
        } else {
            document.getElementById('pathInput').value = 'C:\\photo';
        }
        if (json.trimmerWithBorder !== undefined) {
            document.getElementById('withBorderCheckbox').checked = json.trimmerWithBorder === 'true' ? true : false;
        } else {
            document.getElementById('withBorderCheckbox').checked = true;
        }
        if (json.trimmerWhiteBorderSize !== undefined) {
            document.getElementById('whiteBorderSizeInput').value = json.trimmerWhiteBorderSize;
        } else {
            document.getElementById('whiteBorderSizeInput').value = '10';
        }
    } catch (e) {
        console.log(e);
        closePopup(settingsContainer);
    }
}

document.getElementById('closeSettingsButton').onclick = () => {
    closePopup(document.getElementById('settingsContainer'));
}

document.getElementById('whiteBorderSizeInput').oninput = (ev) => {
    try {
        const value = Number.parseInt(ev.target.value);
        if (value < 0) {
            ev.target.value = '0';
        } else if (value > 999) {
            ev.target.value = '999';
        }
    } catch (e) {
        ev.target.value = '0';
    }
}

document.getElementById('configSaveButton').onclick = async () => {
    document.getElementById('settingSaveError').style.display = 'none';
    try {
        const res = await fetch(`${serverIpPort}/api/config`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                path: document.getElementById('pathInput').value,
                trimmerWithBorder: document.getElementById('withBorderCheckbox').checked.toString(),
                trimmerWhiteBorderSize: document.getElementById('whiteBorderSizeInput').value
            }),
        });
    } catch (e) {
        console.log(e);
        document.getElementById('settingSaveError').style.display = 'inline';
    }
}

let state = [];
let url = '';

const getUrlBase = () => document.URL.replace(/(\?.*)|(\#.*)/g, '');
const getUrlBecover = () => document.URL;

const urlExceptions = new Map([
    ["becover.com.ua", getUrlBecover]
]);

const getUrl = () => {
    const urlFunc = urlExceptions.get(window.location.hostname) || getUrlBase;
    return urlFunc();
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getState") {
        if (getUrl() !== url) {
            state = [];
        }
        sendResponse({ state });
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "setState") {
        state = request.state;
        url = getUrl();
        sendResponse(true);
    }
});

let pageLoaded = false;

window.onload = () => {
    pageLoaded = true;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getLoadStatus") {
        sendResponse({ status: pageLoaded });
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        if (document.title === 'Split') {
            const photoContainer = document.getElementById("photoContainer");
            let imgsFromSplit = Array.from(photoContainer.querySelectorAll('.itemContainer')).map(el => {
                const code = Array.from(el.querySelectorAll('h3'))[0].innerText;
                const links = Array.from(el.querySelectorAll('img')).map(img => img.src);
                return { folderName: code, urls: links };
            });
            sendResponse( {imgsFromSplit} );
        }
        //const imgs = Array.from(document.querySelectorAll(".container-main .bxslider img")).map(el => el.src.replace(/(\/styles\/w1024\/public)|(\?.*)/g, ''));
        //sendResponse({ imgs });
    }
});

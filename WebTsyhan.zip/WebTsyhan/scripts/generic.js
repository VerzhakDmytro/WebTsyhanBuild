let state = [];
let url = '';

const getUrl = () => {
    return document.URL.replace(/(\?.*)|(\#.*)/g, '');
}

window.addEventListener('popstate', function(event) {
        console.log('URL changed due to popstate:', window.location.href);
    });

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getState") {
        if (getUrl() !== url) {
            state = [];
        }
        sendResponse({ state });
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "setState") {
        state = request.state;
        url = getUrl();
        sendResponse(true);
    }
});

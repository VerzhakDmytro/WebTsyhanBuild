let state = [];
let url = '';

const getUrl = () => {
    return document.URL.replace(/(\?.*)|(\#.*)/g, '');
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getState") {
        if (getUrl() !== url) {
            state = [];
        }
        sendResponse({ state });
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "setState") {
        state = request.state;
        url = getUrl();
        sendResponse(true);
    }
});

let state = [];
let url = '';

const getUrlBase = () => document.URL.replace(/(\?.*)|(\#.*)/g, '');
const getUrlBecover = () => document.URL;

const urlExceptions = new Map([
    ["becover.com.ua", getUrlBecover]
]);

const getUrl = () => {
    const urlFunc = urlExceptions.get(window.location.hostname) || getUrlBase;
    return urlFunc();
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getState") {
        if (getUrl() !== url) {
            state = [];
        }
        sendResponse({ state });
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "setState") {
        state = request.state;
        url = getUrl();
        sendResponse(true);
    }
});

let pageLoaded = false;

window.onload = () => {
    pageLoaded = true;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getLoadStatus") {
        sendResponse({ status: pageLoaded });
    }
});

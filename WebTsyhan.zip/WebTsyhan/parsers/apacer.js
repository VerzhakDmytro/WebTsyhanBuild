chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.left-block .prod-intro-container .prod-intro-lv1-swiper-wrapper .swiper-wrapper img')).map(el => el.src);
        sendResponse({ imgs });
    }
});
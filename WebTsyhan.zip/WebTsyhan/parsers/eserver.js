chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.es-slider-container .swiper-wrapper .swiper-slide:not(.swiper-slide-duplicate) img')).map(el => el.src.replace(/(\/rs)|(_*rs.*(?=\.))/g, ''));
        sendResponse({ imgs });
    }
});
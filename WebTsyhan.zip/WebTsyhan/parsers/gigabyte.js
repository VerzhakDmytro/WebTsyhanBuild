chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".tab-gallery-content .model-gallery-modal-body .modal-thumbnail-side .modal-thumbnail-slider .swiper-wrapper .swiper-slide picture"))
            .map((el) => el.dataset.bigSrc);
        sendResponse({ imgs });
    }
});
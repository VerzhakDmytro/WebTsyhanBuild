chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.section-products-card .section__left .section__photos img')).map(el => el.src);
        sendResponse({ imgs });
    }
});
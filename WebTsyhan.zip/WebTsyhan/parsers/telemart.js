chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".card-block__gallery-main .swiper-wrapper .swiper-slide img.zoomImg")).map(el => el.src);
        sendResponse({ imgs });
    }
});
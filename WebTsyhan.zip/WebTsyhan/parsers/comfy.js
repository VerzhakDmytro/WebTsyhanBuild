chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = JSON.parse(
            Array.from(
                document.querySelectorAll("body > script"))
                .filter(el => el.innerHTML.startsWith("window.__INITIAL_STATE__={"))[0].innerHTML.slice(25))
                .product.product.images.map(el => {
                    const url = new URL(el.url, document.baseURI);
                    url.hostname = "cdn." + url.hostname;
                    return url.href;
                });
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.gallery__carousel .q-carousel__slides-container img')).map(el => el.src.replace(/\/w_.*/g,'/f_auto'));
        sendResponse({ imgs });
    }
});
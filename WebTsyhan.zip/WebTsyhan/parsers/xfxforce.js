chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.pdp-img-wrappper .w-slider .w-slider-mask img:not(.w-dyn-bind-empty)')).map(el => el.src);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            const imgs = Array.from(
                document.querySelectorAll(".card_page-cont .slider-for .slick-track .slick-slide a"))
                .map(el => el.href.replace('/resize_cache/webp/upload', ''));

            const linkPromises = imgs.map(link => new Promise((resolve) => {
                const origExt = '.webp';
                const exts = ['.jpg', '.jpeg', '.png', '.avif'];
                const extPromises = exts.map(ext => new Promise(async (resolve, reject) => {
                    const reg = new RegExp(String.raw`${origExt}`, "g");
                    const testLink = link.replace(reg, ext);
                    const res = await fetch(testLink, { method: 'HEAD' });
                    if (res.status !== 200) {
                        reject();
                    } else {
                        resolve(testLink);
                    }
                }));
                Promise.any(extPromises).then(validLink => resolve(validLink));
            }));
            //Promise.all(linkPromises).then(validLinks => sendResponse({ imgs: validLinks }));
            Promise.all(linkPromises).then(validLinks => sendResponse({ imgs: [] }));
        }
    })();
    return true;
});
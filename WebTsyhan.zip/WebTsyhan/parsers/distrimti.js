chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.main-contant .product_slider_wr .product_top .product_slider #zoomer #imageContainerSlider .slick-track .slick-slide:not(.slick-cloned) img'))
            .map(el => el.src);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll("gallery gallery-slider gallery-item gallery-image img")).map(el => el.src);
        sendResponse({ imgs });
    }
});
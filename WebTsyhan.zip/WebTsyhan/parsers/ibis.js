// chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
//     if (request.action === "getImgs") {
//         const imgs = Array.from(
//             document.querySelectorAll('.swiper.swiper-horizontal.swiper-thumbs .swiper-wrapper img'))
//             .map(el => el.src);
//         sendResponse({ imgs });
//     }
// });

window.onload = (ev) => {
    Array.from(document.querySelectorAll('p, span')).forEach(el => el.setAttribute('data-copy-protection', 0))
}

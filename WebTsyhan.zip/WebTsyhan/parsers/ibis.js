chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.swiper.swiper-horizontal.swiper-thumbs .swiper-wrapper img'))
            .map(el => el.src);
        sendResponse({ imgs });
    }
});
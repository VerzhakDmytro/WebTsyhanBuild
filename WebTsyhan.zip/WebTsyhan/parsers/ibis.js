chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const swiper = document.querySelectorAll('.swiper.swiper-horizontal.swiper-thumbs');
        let imgs = [];
        if (swiper.length > 0) {
            imgs = Array.from(
                swiper[0].querySelectorAll('.swiper-wrapper img'))
                .map(el => el.src);
        }
        sendResponse({ imgs });
    }
});

window.onload = (ev) => {
    Array.from(document.querySelectorAll('p, span')).forEach(el => el.setAttribute('data-copy-protection', 0))
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        let imgs = Array.from(document.querySelectorAll(".store-product-image.active .rd-thumbnail-carousel li img")).map((el) => el.src.replace(/\.thumb\..*/g, ""));
        imgs = [...imgs, ...Array.from(document.querySelectorAll(".store-product-image.active .rd-thumbnail-carousel li div.product-image-thumbnail:not(.play-btn)")).map((el) => getComputedStyle(el)['background-image'].slice(4, -1).replace(/"/g, "").replace(/\.wdthumb\..*/g, ""))];
        sendResponse({ imgs });
    }
});
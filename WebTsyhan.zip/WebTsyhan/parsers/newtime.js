chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.prod_gallery .prod_images_swiper .swiper-wrapper img')).map(el => el.src);
        sendResponse({ imgs });
    }
});
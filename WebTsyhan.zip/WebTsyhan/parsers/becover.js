chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.item_main_info .img_wrapper .item_slider .flex-viewport ul.slides li a.fancy')).map(el => el.href);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = JSON.parse(
            Array.from(
                document.querySelectorAll("script[type='application/ld+json']"))
                .map(el => el.innerText)
                .filter(el => el.startsWith('{"@context":"https://schema.org/","@type":"Product"')))
                .image.map(el => el.replace(/_w\d*_h\d*_/g, '_'));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = JSON.parse(Array.from(
            document.querySelectorAll('head > script'))
            .filter(el => el.textContent.slice(0, 50).startsWith(`{"@context":"https://schema.org/","@type":"Product`))[0]
            .textContent.match(/(?<=\"image\":).*?](?=,)/g)[0]);
        sendResponse({ imgs });
    }
});
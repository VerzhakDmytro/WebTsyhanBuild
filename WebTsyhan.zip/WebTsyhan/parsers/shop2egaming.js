chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product-main__gallery .product-gallery .product-gallery__big .product-gallery__big-slider .slick-list .slick-track .slick-slide a'))
            .map(el => el.href);
        sendResponse({ imgs });
    }
});
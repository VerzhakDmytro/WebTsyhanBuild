chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll("img.item-img.pdc-gallery-thumb")).map((el) => el.src.replace(/w80/g, ""));
        sendResponse({ imgs });
    }
});
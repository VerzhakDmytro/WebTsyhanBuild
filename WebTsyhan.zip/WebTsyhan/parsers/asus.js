chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelector("#product_gallery")?.shadowRoot
            .querySelectorAll('.galleryShow .galleryShowNormal .galleryThumbnailsContainer .galleryThumbnails .thumbnails-wrapper img'))
            .map(el => el.src.replace(/w80/g, ""));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.prodSlWr .prodSlNav.itemGrid img')).map(el => el.src.replace(/\/size_60\//g, '/'));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.card-header__card-images .card-header__card-images-list.swiper-wrapper img')).map(el => el.src);
        sendResponse({ imgs });
    }
});
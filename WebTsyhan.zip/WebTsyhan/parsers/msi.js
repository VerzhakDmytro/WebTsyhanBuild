chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll("#lightgallery img")).map((el) => el.src);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.swiper-container-horizontal > div > div > picture > img'))
            .map(el => el.src);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.pdpv__inner #mixedmedia_container #mixedmedia_swatches #mixedmedia_swatches_listbox .s7thumbcell .s7thumb'))
            .map(el => getComputedStyle(el)['background-image'].slice(4, -1).replace(/"/g, "")
            .replace(/&hei=\d*/g, '')
            .replace(/&wid=\d*/g, '&wid=4800'));
        sendResponse({ imgs });
    }
});
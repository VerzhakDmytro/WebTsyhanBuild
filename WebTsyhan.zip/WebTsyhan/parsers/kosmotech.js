chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".cart-image-small-item a")).map((el) => el.src.replace(/\/medium\//g, "/original/"));
        sendResponse({ imgs });
    }
});
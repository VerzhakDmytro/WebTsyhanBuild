chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".cart-image-small .cart-image-small-item a")).map(el => el.href);
        sendResponse({ imgs });
    }
});
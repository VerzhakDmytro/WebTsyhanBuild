chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.cs-product-image img.cs-product-image__img, .cs-images__img')).map(el => el.src.replace(/_w\d*_h\d*_/g, '_'));
        sendResponse({ imgs });
    }
});
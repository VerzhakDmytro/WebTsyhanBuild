chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.product__card .summary-swiper .summary-swiper__container .summary-swiper__slider .swiper-wrapper .swiper-zoom-container img')).map(el => el.src);
        sendResponse({ imgs });
    }
});
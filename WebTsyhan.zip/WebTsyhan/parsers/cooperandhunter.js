chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.slider .slider__container .slick-list .slick-track img')).map(el => el.src);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('div > div > img[src^="https://stls.store/cdn_thumbs_webp/500-500"]'))
            .map(el => el.src.replace(/(\/cdn_thumbs_webp\/500-500)|(.webp$)/g, ''));
        sendResponse({ imgs });
    }
});
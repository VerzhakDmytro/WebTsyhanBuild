chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.chakra-stack .swiper-wrapper .swiper-slide img')).map(el => el.src.replace(/\/size\/lg\/products\//g, '/size/xl/products/'));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.about-product-row-sliders .slider-for .slick-track .slick-slide a'))
            .map(el => el.href);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.carousel--product-images .slick-list .slick-track .slick-slide:not(.slick-cloned) a')).map(el => el.href);
        sendResponse({ imgs });
    }
});
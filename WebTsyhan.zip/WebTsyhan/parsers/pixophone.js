chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.gen-tab__carousel-container-img ul.splide__list:not(.thumbnails) li img'))
            .map(el => el.src.replace(/(?<=\/image\/)cache\//g, '').replace(/-\d*x\d*\.webp/g, '.jpg'));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.inno3d-product__product-images .inno3d-product__product-images--big-image.big-image img')).map(el => el.src);
        sendResponse({ imgs });
    }
});
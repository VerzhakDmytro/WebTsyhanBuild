chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('ul.thumbnails li a.thumbnail'))
            .map(el => el.href.replace(/((?<=\/image\/)cache\/)|(-\d*x\d*(?=.))/g, ''));
        sendResponse({ imgs });
    }
});
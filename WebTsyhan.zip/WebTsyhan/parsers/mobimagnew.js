chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.gallery .splide__track .splide__list .splide__slide:not(.splide__slide--clone) a'))
            .map(el => el.href);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product-navbar .tabs .tab__item.fotos .f-carousel .f-carousel__track .f-carousel__slide'))
            .filter(el => el.dataset.type === 'image')
            .map(el => new URL(el.dataset.src, el.baseURI).href);
        sendResponse({ imgs });
    }
});
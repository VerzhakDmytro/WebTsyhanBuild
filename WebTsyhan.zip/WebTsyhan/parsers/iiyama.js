chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll("ul.thumbs li img")).map(el => el.src.replace(/(?<=\/i\/)\d*x\d*?(?=x)/g, '2000x2000'));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product__content .product__gallery .product__slider .product__slider-main .swiper-wrapper .swiper-slide a'))
            .map(el => el.href.replace(/(?<=\.)\d\d\d(?=\.)/g, '1000'));
        sendResponse({ imgs });
    }
});
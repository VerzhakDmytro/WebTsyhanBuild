chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.slick-slider .slick-list .slick-track .slick-slide img')).map(el => el.src);
        sendResponse({ imgs });
    }
});
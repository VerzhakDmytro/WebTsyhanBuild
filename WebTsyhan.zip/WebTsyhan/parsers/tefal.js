chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('[class^=carousel-carouselContainer] .slick-slider .slick-list .slick-track button img:not([class*=image-placeholder]):not([class*=label-image])')).map(el => el.src.replace(/\?.*/g,''));
        sendResponse({ imgs });
    }
});
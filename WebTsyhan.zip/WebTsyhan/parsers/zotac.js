chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".container-main .bxslider img")).map(el => el.src.replace(/(\/styles\/w1024\/public)|(\?.*)/g, ''));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".b-offer-table .b-offer-table__left .slick-offer-img .slick-track .slick-offer-img__slide img"))
            .map(el => el.src);
        //sendResponse({ imgs });
        sendResponse({  });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".card.product .product__gallery .gallery__track img"))
            .map(el => el.src);
        //sendResponse({ imgs });
        sendResponse({  });
    }
});
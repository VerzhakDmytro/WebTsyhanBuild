chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('section.swiper.w-full .swiper-wrapper .swiper-slide img')).map(el => el.src.replace(/\?.*/g, ''));
        sendResponse({ imgs });
    }
});
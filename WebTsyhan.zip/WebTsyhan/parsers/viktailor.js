chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            let imgs = Array.from(
                document.querySelectorAll('.product__section--gallery .gallery .gallery__photos .gallery__photos-container .gallery__photos-list .gallery__item img.gallery__photo-img'))
                .map(el => el.src.replace(/\/\d*x\d*l\d*nn\d*/g, '').replace(/\.webp/g, '.jpg'));

            for (let i = 0; i < imgs.length; i++) {
                const ext = ['.jpg', '.png', '.jpeg'];
                for (let j = 0; j < ext.length - 1; j++) {
                    const res = await fetch(imgs[i]);
                    if (res.status !== 200) {
                        const reg = new RegExp(String.raw`${ext[j]}`, "g");
                        imgs[i] = imgs[i].replace(reg, ext[j + 1]);
                        console.log(imgs[i]);
                    } else break;
                }
            };
            sendResponse({ imgs });
        }
    })();
    return true;
});
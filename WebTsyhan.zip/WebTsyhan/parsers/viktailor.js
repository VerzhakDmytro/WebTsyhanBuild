chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            let imgs = Array.from(
                document.querySelectorAll('.product__section--gallery .gallery .gallery__photos .gallery__photos-container .gallery__photos-list .gallery__item img.gallery__photo-img'))
                .map(el => el.src.replace(/\/\d*x\d*l\d*nn\d*/g, '').replace(/\.webp/g, '.jpg'));

            for (let i = 0; i < imgs.length; i++) {
                const res = await fetch(imgs[i]);
                if (res.status !== 200) {
                    imgs[i] = imgs[i].replace(/\.jpg/g, '.png');
                }
            };
            sendResponse({ imgs });
        }
    })();
    return true;
});
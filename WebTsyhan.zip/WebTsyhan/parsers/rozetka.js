chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        let imgs = Array.from(document.querySelectorAll("rz-gallery-main-thumbnail-image img")).map((el) => el.src.replace(/\/medium\//g, "/original/"));
        if (!imgs.length) {
            imgs = Array.from(new Set(Array.from(document.querySelectorAll("rz-gallery-main-content-image img")).map((el) => el.src.replace(/\/big\//g, "/original/"))));
        }
        sendResponse({ imgs });
    }
});
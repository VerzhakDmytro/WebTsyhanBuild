chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product-top__container .product-top__left .product-slider__big .slick-track .product-slider__big-item:not(.product-slider_youtube_video) a'))
            .map(el => el.href);
        sendResponse({ imgs });
    }
});
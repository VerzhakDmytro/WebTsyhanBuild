chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            const imgs = Array.from(document.querySelectorAll(".item-gallery .ls-wrapper .ls-scroller .ls-item img")).map(el => {
                const parts = el.src.match(/\/cache\/asp(\d*)\/(.*)(?=-fill-)/);
                return `https://velotrade.com.ua/assets/sgallery/product/${parts[1]}/${parts[2]}.jpeg`;
            });
            const linkPromises = imgs.map(link => new Promise((resolve) => {
                const origExt = '.jpeg';
                const exts = ['.jpeg', '.webp', '.png', '.jpg', '.avif'];
                const extPromises = exts.map(ext => new Promise(async (resolve, reject) => {
                    const reg = new RegExp(String.raw`${origExt}`, "g");
                    const testLink = link.replace(reg, ext);
                    const res = await fetch(testLink, { method: 'HEAD' });
                    if (res.status !== 200) {
                        reject();
                    } else {
                        resolve(testLink);
                    }
                }));
                Promise.any(extPromises).then(validLink => resolve(validLink));
            }));
            Promise.all(linkPromises).then(validLinks => sendResponse({ imgs: validLinks }));
        }
    })();
    return true;
});
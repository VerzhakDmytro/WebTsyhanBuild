chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.albumBox .albumList.albumListMain .slick-track .albumItem.slick-slide:not(.slick-cloned) img'))
            .map(el => el.src);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".product-media-wrapper.only-desktop .product-media-gallery .slick-list .slick-track .product-image-slide:not(.video-thumbnail) img")).map(el => el.src.replace(/medium-png/g, "large-png"));;
        sendResponse({ imgs });
    }
});
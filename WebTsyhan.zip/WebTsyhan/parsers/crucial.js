chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".product-carousel .custom__embla__container .custom__embla__slide .cmp-teaser__image picture img"))
            .map(el => el.src.replace(/\/renditions\/transformpng-\d*-\d*.png\//g, '\/original\/'));
        sendResponse({ imgs });
    }
});
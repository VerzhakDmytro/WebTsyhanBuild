chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.image-container .swiper-container.swiper-thumbs .swiper-wrapper .v-image__image--contain:not(.v-image__image--preload)'))
            .map(el => el.style["background-image"].slice(4, -1).replace(/"/g, ""))
            .map(el => el.replace(/(?<=\/)\d*(?=\.)/g, Number.parseInt(el.match(/(?<=\/)\d*(?=\.)/g)[0]) - 4));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        (async () => {
            const id = document.URL.match(/\d*$/g)[0];
            const res = await fetch(`https://product.yugcontract.ua/get-product`, {
                method: 'POST', body: JSON.stringify({ "typhoon_id": id, "lang_key": "ua" }), headers: {
                    'Content-Type': 'application/json',
                    'server-name': 'b2b.yugcontract.ua'
                }
            });
            const json = await res.json();
            const imgs = json.content.images.map(el => `https://b2b.yugcontract.ua/fileslibrary/products/${json.content.id}/${el.full_filename}`);
            sendResponse({ imgs });
        })();
        return true;
    }
});
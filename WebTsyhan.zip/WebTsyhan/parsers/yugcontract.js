chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.agile.slide .agile__list .agile__track .agile__slides.agile__slides--regular .v-image__image--contain:not(.v-image__image--preload)'))
            .map(el => el.style["background-image"].slice(4, -1).replace(/"/g, ""))
            .map(el => el.replace(/(?<=\/)\d*(?=\.)/g, Number.parseInt(el.match(/(?<=\/)\d*(?=\.)/g)[0]) - 1));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.card_item_img .images .thumbs img')).map(el => el.src).filter(el => el !== 'https://megabite.ua/pix/img/video.png').map(el => el.replace(/\/thumb\./g, '/original.'));
        sendResponse({ imgs });
    }
});
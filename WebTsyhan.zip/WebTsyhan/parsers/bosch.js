chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.swiper.swiper-horizontal .swiper-wrapper .swiper-slide img'))
            .map(el => el.src.replace(/(?<=\/Product_Shots\/)\d*x\//g, ''));
        sendResponse({ imgs });
    }
});
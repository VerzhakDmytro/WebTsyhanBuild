chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.rm-product-images .rm-product-images-main .slick-list .slick-track .rm-product-slide:not(.slick-cloned) a'))
            .map(el => el.href.replace(/(\/cache)|(-\d*x\d*(?=\.))/g, ''));
        sendResponse({ imgs });
    }
});
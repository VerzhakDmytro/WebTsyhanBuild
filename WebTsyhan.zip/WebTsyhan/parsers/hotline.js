chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        let imgs = [];
        try {
            imgs = Array.from(document.querySelectorAll(".zoom-gallery__nav-list")[1].querySelectorAll(".zoom-gallery__nav-item--image img")).map((el) => el.src.replace(/1.jpg/g, "5.jpg"));
            if (imgs.length < 1) throw 'null';
        } catch {
            imgs = Array.from(document.querySelectorAll(".main-block.content")[0].querySelectorAll(".zoom-gallery__nav-item--image img")).map((el) => el.src.replace(/1.jpg/g, "5.jpg"));
        }
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".zoom-gallery__nav-list")[1].querySelectorAll('img')).map((el) => el.src.replace(/1.jpg/g, "5.jpg"));
        sendResponse({ imgs });
    }
});
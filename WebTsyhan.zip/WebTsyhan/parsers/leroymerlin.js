chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product-detail-container .w-carousel #product-carousel .m-carousel-main .kl-swiper__slider .kl-swiper__slider-item.m-carousel-main__item picture source:first-child'))
            .map(el => el.srcset.replace(/\?.*/g, ''));
        sendResponse({ imgs });
    }
});
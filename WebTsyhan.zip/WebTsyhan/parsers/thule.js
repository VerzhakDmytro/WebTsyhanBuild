chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.thule-container .splide .splide__list picture source')).map(el => el.srcset);
        sendResponse({ imgs });
    }
});
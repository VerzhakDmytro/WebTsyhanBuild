chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product .product__gallery.gallery .gallery__slider a.product-slider__slide'))
            .map(el => el.href);
        sendResponse({ imgs });
    }
});
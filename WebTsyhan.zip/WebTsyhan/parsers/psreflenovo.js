chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            new Set(
                Array.from(
                    document.querySelectorAll('main .detail-page-wrapper .hero-as-show section.pp-carousel .pp-media-frame .pp-media-track .pp-media-slide img'))
                    .map(el => el.src.replace(/\/Compressedimage/g, ''))));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            new Set(
                Array.from((document.querySelector('html iframe') !== null ? document.querySelector('html iframe').contentWindow.document : document).querySelectorAll('.mainbox .as_box .as_banner .as_small .slide .pic img'))
                    .map(el => el.src.replace(/\/Compressedimage/g, ''))));
        sendResponse({ imgs });
    }
});
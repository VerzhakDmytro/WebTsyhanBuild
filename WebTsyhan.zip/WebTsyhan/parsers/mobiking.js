chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('section.product-detail .product-detail__container .product-gallery-widget__gallery .gallery__inner .gallery-slider .gallery-slider__swiper .swiper-slide img'))
            .map(el => el.src.replace(/_thumbnail/g, ''));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".main-image:not(.imgfix )")).map(el => el.src);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            const imgs = Array.from(
                document.querySelectorAll(".main-image:not(.imgfix )"))
                .map(el => el.src.replace(/\/cache\/catalog\/image\/cache/g, '').replace(/-\d\d\dx\d\d\d\.webp/g, '.jpg'));

            for (let i = 0; i < imgs.length; i++) {
                const res = await fetch(imgs[i]);
                if (res.status !== 200) {
                    imgs[i] = imgs[i].replace(/\.jpg/g, '.jpeg');
                }
            };
            sendResponse({ imgs });
        }
    })();
    return true;
});
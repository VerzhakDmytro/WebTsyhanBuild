chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.card-slider__big-wrap .card-slider__big .slick-track a')).map(el => el.href);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product_wrap .product_main .product_gallery .product_gallery_main .swiper-wrapper .swiper-slide > div'))
            .map(el => el.dataset.src.replace(/((?<=\/image\/)cache\/)|(-\d*x\d*(?=\.[jJ][pP][gG]))/g, ''));
        sendResponse({ imgs });
    }
});
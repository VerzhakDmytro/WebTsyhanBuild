chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.catalog-element-gallery .owl-stage-outer .owl-stage a')).map(el => el.href);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('#sliderModal li source[type="image/png"]'))
            .map(el => el.dataset.href);
        sendResponse({ imgs });
    }
});
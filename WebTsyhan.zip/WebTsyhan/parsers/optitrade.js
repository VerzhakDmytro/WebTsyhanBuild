chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".us-product .us-product-photo-main .slick-list .slick-track .us-product-slide:not(.slick-cloned) img")).map(el => el.src.replace(/(\/cache)|(-1000x1000)/g, ''));
        sendResponse({ imgs });
    }
});
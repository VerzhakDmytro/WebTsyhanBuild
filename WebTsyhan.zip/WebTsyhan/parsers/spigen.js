chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.m-main-product .m-main-product--wrapper .m-main-product--media .m-product-media--desktop media-gallery .m-product-media--item img'))
            .map(el => el.src.replace(/\?.*/g,''));
        sendResponse({ imgs });
    }
});
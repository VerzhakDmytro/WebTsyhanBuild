chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            let imgs = Array.from(
                document.querySelectorAll('.product .product__grid .product__section--gallery .gallery .gallery__photos .gallery__photos-container .gallery__photos-list span.gallery__link'))
                .map(el => new URL(el.dataset.href
                    .replace(/(?<=\/images\/\d*)\/.*?(?=\/)/g, ''), document.baseURI).href);

            const linkPromises = imgs.map(link => new Promise((resolve) => {
                const origExt = '.webp';
                const exts = ['.jpeg', '.png', '.jpg'];
                const extPromises = exts.map(ext => new Promise(async (resolve, reject) => {
                    const reg = new RegExp(String.raw`${origExt}`, "g");
                    const testLink = link.replace(reg, ext);
                    const res = await fetch(testLink, { method: 'HEAD' });
                    if (res.status !== 200) {
                        reject();
                    } else {
                        resolve(testLink);
                    }
                }));
                Promise.any(extPromises).then(validLink => resolve(validLink));
            }));
            Promise.all(linkPromises).then(validLinks => sendResponse({ imgs: validLinks }));
        }
    })();
    return true;
});
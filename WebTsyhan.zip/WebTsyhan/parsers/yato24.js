chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product .product__grid .product__section--gallery .gallery .gallery__photos .gallery__photos-container .gallery__photos-list span.gallery__link'))
            .map(el => new URL(el.dataset.href.replace(/(?<=\/images\/\d*)\/.*?(?=\/)/g, '').replace(/\.webp/g, '.jpeg'), document.baseURI).href);
        sendResponse({ imgs });
    }
});
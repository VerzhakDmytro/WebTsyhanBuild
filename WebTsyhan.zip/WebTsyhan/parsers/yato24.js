chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            let imgs = Array.from(
                document.querySelectorAll('.product .product__grid .product__section--gallery .gallery .gallery__photos .gallery__photos-container .gallery__photos-list span.gallery__link'))
                .map(el => new URL(el.dataset.href
                    .replace(/(?<=\/images\/\d*)\/.*?(?=\/)/g, '')
                    .replace(/\.webp/g, '.jpeg'), document.baseURI).href);

            for (let i = 0; i < imgs.length; i++) {
                const res = await fetch(imgs[i]);
                if (res.status !== 200) {
                    imgs[i] = imgs[i].replace(/\.jpeg/g, '.png');
                }
            };
            sendResponse({ imgs });
        }
    })();
    return true;
});
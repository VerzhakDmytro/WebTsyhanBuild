chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.top-slider-container .owl-stage-outer .owl-stage .owl-item img'))
            .map(el => el.dataset.src);
        sendResponse({ imgs });
    }
});
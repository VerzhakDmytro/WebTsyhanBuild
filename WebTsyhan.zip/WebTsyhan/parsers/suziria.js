chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".primary_block .left-thumbs-table #views_block #thumbs_list #thumbs_list_frame li.slick-slide a"))
            .map(el => el.href.replace(/-thickbox_default/g, ''));
        sendResponse({ imgs });
    }
});
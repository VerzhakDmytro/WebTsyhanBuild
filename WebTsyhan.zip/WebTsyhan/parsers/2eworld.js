chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product-main__container .product-gallery .swiper-container.product-gallery__main .swiper-wrapper .swiper-slide a'))
            .map(el => el.href);
        sendResponse({ imgs });
    }
});
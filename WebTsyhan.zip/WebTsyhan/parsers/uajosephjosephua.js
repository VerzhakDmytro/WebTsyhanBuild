chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll("main .container .product-box .slider-product-block .master-slider .ms-container .ms-slide-container .ms-slide img"))
            .map(el => el.src);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            const id = document.querySelector('.img200 img').src.match(/(?<=\/jpg\/).*?(?=\.)/g)[0];
            const res = await fetch(`https://m.ua/ua/mtools/mui_get_img_gallery.php?idg_=${id}&f_type_=IMG&callback=jQuery37105212695956789303_1751146279733&_=1751146279734`);
            const resJson = await res.text();
            let imgs = JSON.parse(resJson.match(/(?<=\(){.*}(?=\))/gm)[0]).pp_images;
            if (imgs.length > 0) {
                imgs[0] = new URL(imgs[0], document.baseURI).href;
            }
            sendResponse({ imgs });
        }
    })();
    return true;
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product-overview .product-gallery .product-gallery__main .product-gallery__image-wrap .product-gallery__main-slider .product-gallery__main-wrapper .product-gallery__main-slide img'))
            .map(el => el.src.replace(/\/cdn\/resize:\d*:\d*/g, ''));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.main .product-hero .product-hero__inner .product-hero__photo .product-hero__main-wrapper .product-hero__main.swiper .swiper-wrapper img'))
            .map(el => el.src.replace(/\/cdn\/resize\:\d*\:\d*/g, ''));
        sendResponse({ imgs });
    }
});
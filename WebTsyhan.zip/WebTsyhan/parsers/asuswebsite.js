chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('#carousel-product-image .carousel-inner .carousel-item picture source'))
            .map(el => new URL(el.srcset, document.baseURI).href);
        sendResponse({ imgs });
    }
});
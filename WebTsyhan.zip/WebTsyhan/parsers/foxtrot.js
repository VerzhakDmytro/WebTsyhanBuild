chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs =  Array.from(document.querySelectorAll(".pdp-preview-slider-contaier .owl-stage img")).map((el) => el.src.replace(/_Small/g, ""));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll("main .pdp-content-wrap .pdp-main-photo-side .pdp-main-slider-img-container .pdp-main-img-container .pdp-main-img:not(.clone) img"))
            .map((el) => el.src);
        sendResponse({ imgs });
    }
});
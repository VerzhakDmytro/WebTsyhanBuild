chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            new Set(Array.from(
                document.querySelectorAll('.product-main .product-media #image-block .MagicToolboxContainer .MagicToolboxSelectorsContainer .mcs-wrapper .mcs-items-container .mcs-item a'))
                .map(el => el.href)));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".product-left .images .small-img-wrapper img")).map(el => el.src.replace(/.100x100./g, '.800x600w.'));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".s-product__content .s-product-photos .s-photos-list li.s-photo-thumb a"))
            .map(el => el.href.replace(/(?<=\.)\d*(?=\.)/g, '2000'));
        sendResponse({ imgs });
    }
});
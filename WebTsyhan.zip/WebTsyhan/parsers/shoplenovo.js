chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            const id = document.querySelector('.product-main-actions-item.__compare.to-compare').dataset['product'];
            const res = await fetch(`https://shop.lenovo.ua/api/products/${id}/images/gallery/`);
            const resJson = await res.json();
            const imgs = resJson.data.picture_list;
            sendResponse({ imgs });
        }
    })();
    return true;
});
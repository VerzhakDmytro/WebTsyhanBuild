chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            let imgs = Array.from(
                document.querySelectorAll(".row.product-image .swiper.swiper-main img"))
                .map((el) => el.src.replace(/(?<=\/image\/)cache\//g, '').replace(/-\d*x\d*\.webp/g, '.jpg'));

            for (let i = 0; i < imgs.length; i++) {
                const res = await fetch(imgs[i]);
                if (res.status !== 200) {
                    imgs[i] = imgs[i].replace(/\.jpg/g, '.webp');
                }
            };
            sendResponse({ imgs });
        }
    })();
    return true;
});
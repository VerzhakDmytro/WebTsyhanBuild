chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            let imgs = Array.from(
                document.querySelectorAll(".row.product-image .swiper.swiper-main img"))
                .map((el) => el.src.replace(/(?<=\/image\/)cache\//g, '').replace(/-\d*x\d*\.webp/g, '.jpg'));
            if (imgs.length > 0) {
                const res = await fetch(imgs[0]);
                if (res.status !== 200) {
                    imgs = Array.from(
                        document.querySelectorAll(".row.product-image .swiper.swiper-main img"))
                        .map((el) => el.src.replace(/(?<=\/image\/)cache\//g, '').replace(/-\d*x\d*(?=\.)/g, ''));
                }
            }
            sendResponse({ imgs });
        }
    })();
    return true;
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".row.product-image .swiper.swiper-main img"))
            .map((el) => el.src.replace(/(?<=\/image\/)cache\//g, '').replace(/-\d*x\d*\.webp/g, '.jpg'));
        sendResponse({ imgs });
    }
});
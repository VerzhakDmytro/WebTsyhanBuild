chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".product-content .gallery-block .thumbs-wrap .thumbs-block .thumbs-inner .thumbs-item .big-image picture img"))
            .map(el => new URL(el.dataset.src, document.baseURI).href);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.swiper.productGallerySwiper .swiper-wrapper .swiper-slide a'))
            .map(el => el.href);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".single-product--content .single-product--section1 .lSSlideOuter .cpt_product_images img"))
            .map(el => el.src);
        sendResponse({ imgs });
    }
});
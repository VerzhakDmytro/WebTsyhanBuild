chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".product-main .product-main-carousel .slick-track a"))
            .map(el => el.href.replace(/(?<=\/image\/)cache\/webp/g, '').replace(/-\d*x\d*\.webp/g, '.jpg'));
        sendResponse({ imgs });
    }
});
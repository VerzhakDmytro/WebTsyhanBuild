chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = [
            ...Array.from(document.querySelectorAll('.cs-product .cs-product__image .cs-product-image .cs-product-image__main-img.cs-product-image__main-img_with_images img')),
            ...Array.from(document.querySelectorAll('.cs-product .cs-product__image .cs-product-image .cs-product-image__images.cs-images .cs-images__holder ul.cs-images__list .cs-images__item:not(:has(span)) img'))
        ]
        .map(el => el.src.replace(/_w\d*_h\d*_/g, '_'));
        sendResponse({ imgs });
    }
});
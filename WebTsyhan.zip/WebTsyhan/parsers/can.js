chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".slider-wrapper .preview__list img")).map((el) => el.src.replace(/\/images\/60x60\//g, "/"));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.image-block .thumbnails .general-image .slider-main-img .slick-list .slick-track .item a'))
            .map(el => {
                let url = el.href;
                if (url.includes('/external/')) {
                    url = url.replace(/-\d*x\d*(?=\.webp)/g, '');
                }
                return url;
            });
        sendResponse({ imgs });
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            const imgs = Array.from(
                document.querySelectorAll('.image-block .thumbnails .general-image .slider-main-img .slick-list .slick-track .item a'))
                .map(el => el.href.replace(/(\/cache\/webp)|(-\d*x\d*(?=\.webp))/g, ''));
            const linkPromises = imgs.map(link => new Promise((resolve) => {
                const origExt = '.webp';
                const exts = ['.webp', '.jpg', '.png', '.jpeg'];
                const extPromises = exts.map(ext => new Promise(async (resolve, reject) => {
                    const reg = new RegExp(String.raw`${origExt}`, "g");
                    const testLink = link.replace(reg, ext);
                    const res = await fetch(testLink, { method: 'HEAD' });
                    if (res.status !== 200) {
                        reject();
                    } else {
                        resolve(testLink);
                    }
                }));
                Promise.any(extPromises).then(validLink => resolve(validLink));
            }));
            Promise.all(linkPromises).then(validLinks => sendResponse({ imgs: validLinks }));
        }
    })();
    return true;
});

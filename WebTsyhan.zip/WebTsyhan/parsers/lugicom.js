chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.image-block .thumbnails .general-image .slider-main-img .slick-list .slick-track .item a'))
            .map(el => el.href.replace(/-\d*x\d*(?=\.webp)/g, ''));
        sendResponse({ imgs });
    }
});
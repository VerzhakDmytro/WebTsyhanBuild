chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".product-modal-slider .slick-track .item.slick-slide:not(.slick-cloned) span img.zoomImg")).map(el => el.src);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product-img-box .product-image-gallery img.gallery-image:not(#image-main)'))
            .map(el => el.src.replace(/\/cache\/.*\/image\/.*?\/.*?(?=\/)/g, ''));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product-single .gallery-border.image-tile .lSSlideWrapper ul li.lslide a'))
            .map(el => el.href);
        sendResponse({ imgs });
    }
});
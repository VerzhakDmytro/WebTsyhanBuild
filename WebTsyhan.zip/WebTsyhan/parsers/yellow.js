chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".product-img-block.left-side .product-image-box .thumb-images .thumbnails > div"))
            .map(el => el.dataset.bigSrc.replace(/(?<=media\/catalog\/product\/)cache\/.*\/image\/\d*x\d*\/.*?\//g, ''));
        sendResponse({ imgs });
    }
});
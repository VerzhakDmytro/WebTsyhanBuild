chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.cs-pictures img')).map(el => el.src.replace(/w.*?_.*?_/g, ''));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.product-detail .gallery-preview .slick-track a')).map(el => el.href);
        sendResponse({ imgs });
    }
});
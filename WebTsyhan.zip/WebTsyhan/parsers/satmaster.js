chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            let imgs = Array.from(
                document.querySelectorAll('.gallary-wrapper .addimg_index .rowimg .swiper-container .swiper-wrapper .swiper-slide:not(.yvideo) img'))
                .map(el => el.src.replace(/(\/cachewebp)|(-\d*x\d*(?=\.))/g, '').replace(/\.webp/g, '.jpg'));
            for (let i = 0; i < imgs.length; i++) {
                const res = await fetch(imgs[i]);
                if (res.status !== 200) {
                    imgs[i] = imgs[i].replace(/\.jpg/g, '.png');
                }
            };
            sendResponse({ imgs });
        }
    })();
    return true;
});
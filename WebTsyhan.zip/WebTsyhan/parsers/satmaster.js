chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.gallary-wrapper .addimg_index .rowimg .swiper-container .swiper-wrapper .swiper-slide img'))
            .map(el => el.src.replace(/(\/cachewebp)|(-\d*x\d*(?=\.))/g, '').replace(/\.webp/g, '.jpg'));
        sendResponse({ imgs });
    }
});
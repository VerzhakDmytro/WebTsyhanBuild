chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            const imgs = Array.from(
                document.querySelectorAll("section.gallery .gallery__photos .gallery__photos-container .gallery__photos-list li.gallery__item span"))
                .map(el => new URL(el.dataset.href, document.baseURI).href
                .replace(/(?<=\/images\/\d*\/).*\//g, ''));
            const linkPromises = imgs.map(link => new Promise((resolve) => {
                const origExt = '.webp';
                const exts = ['.jpg', '.png', '.jpeg'];
                const extPromises = exts.map(ext => new Promise(async (resolve, reject) => {
                    const reg = new RegExp(String.raw`${origExt}`, "g");
                    const testLink = link.replace(reg, ext);
                    const res = await fetch(testLink, { method: 'HEAD' });
                    if (res.status !== 200) {
                        reject();
                    } else {
                        resolve(testLink);
                    }
                }));
                Promise.any(extPromises).then(validLink => resolve(validLink));
            }));
            Promise.all(linkPromises).then(validLinks => sendResponse({ imgs: validLinks }));
        }
    })();
    return true;
});
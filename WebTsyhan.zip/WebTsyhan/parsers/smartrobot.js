chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll("section.gallery .gallery__photos .gallery__photos-container .gallery__photos-list li.gallery__item span"))
            .map(el => new URL(el.dataset.href, document.baseURI).href
            .replace(/(?<=\/images\/\d*\/).*\//g, '')
            .replace(/\.webp/g, '.jpg'));
        sendResponse({ imgs });
    }
});
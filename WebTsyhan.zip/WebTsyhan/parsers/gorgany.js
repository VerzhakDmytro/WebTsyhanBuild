let currentColorNode = null;

window.onload = (ev) => {
    Array.from(document.querySelectorAll('.product-options-wrapper .swatch-option')).forEach(el => el.onclick = () => {
        if (currentColorNode !== el) {
            currentColorNode = el;
            url = '';
        }
    });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            new Set(
                Array.from(
                    document.querySelectorAll('.gallery-placeholder .fotorama-item .fotorama__wrap img'))
                    .map(el => el.src.replace(/\?.*/g, '')
                )
            )
        );
        sendResponse({ imgs });
    }
});
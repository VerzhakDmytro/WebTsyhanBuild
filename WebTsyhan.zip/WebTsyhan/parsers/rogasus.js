chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('[class^=ProductGallery__productGallery] [class^=ProductGallery__deskTopGallery] img,[class^=ProductGallery__galleryBottomContent] img')).map(el => el.src.replace(/\/w.*?\/h.*/g, '/w4500/h4132'));
        sendResponse({ imgs });
    }
});
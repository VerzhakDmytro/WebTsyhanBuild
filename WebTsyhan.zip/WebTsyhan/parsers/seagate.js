chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".EcomProductDetail-carousels-mainContainer .swiper-wrapper img")).map((el) => el.src);
        sendResponse({ imgs });
    }
});
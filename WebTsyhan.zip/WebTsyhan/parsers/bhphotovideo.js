chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        (async () => {
            const sku = window.location.pathname.match(/\/product\/(\d+)/)[1];
            const res = await fetch(`https://www.bhphotovideo.com/find/getImages.jsp/sku/${sku}/is/REG`);
            const json = await res.json();

            const imgs = json[0].images.map(img => {
                const levelsArr = img.levels.split(',');
                const maxRes = levelsArr[levelsArr.length - 1];
                return img.srcTemplate.replace('{level}', maxRes);
            });

            sendResponse({ imgs });
        })();
        return true;
    }
});
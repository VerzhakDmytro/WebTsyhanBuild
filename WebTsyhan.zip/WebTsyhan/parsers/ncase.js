chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.gallery .gallery__thumbs .gallery__thumb img')).map(el => el.src);
        sendResponse({ imgs });
    }
});
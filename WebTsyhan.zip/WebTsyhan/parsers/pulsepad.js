chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".product-page .product-page__gallery .gallery_image.product-page__image .product-page__image-img .swiper-wrapper a"))
            .map(el => el.href.replace(/\/files\/resized\//g, '/files/originals/').replace(/\.\d*x\d*w(?=\.)/g, ''));
        sendResponse({ imgs });
    }
});
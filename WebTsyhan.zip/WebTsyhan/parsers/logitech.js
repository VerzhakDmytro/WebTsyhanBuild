chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        let imgs = Array.from(
            document.querySelectorAll('.product-info .popup-gallery .overflow-thumbnails-carousel .thumbnails-carousel .owl-wrapper .owl-item a'))
            .map(el => el.href);
        if (imgs.length > 0) {
            imgs[0] = imgs[0].replace(/-\d*x\d*(?=\.)/g, '').replace(/\/wp\/gp\//g, '/wp/lp/');
        }
        sendResponse({ imgs });
    }
});
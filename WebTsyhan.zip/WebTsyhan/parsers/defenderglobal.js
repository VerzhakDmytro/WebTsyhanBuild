chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.df-product__section__gallery .container .owl-carousel .owl-stage-outer .owl-stage .owl-item a'))
            .map(el => el.href);
        sendResponse({ imgs });
    }
});
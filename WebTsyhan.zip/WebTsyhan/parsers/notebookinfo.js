chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.gallery .image .swipe li picture img'))
            .map(el => el.dataset['fullSize'].replace(/(?<=produkt\/\d*\/).*\/center\/.*\//g, ''));
        sendResponse({ imgs });
    }
});
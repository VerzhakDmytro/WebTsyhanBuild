chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".product__main .swiper.product__slider__view img")).map((el) => el.src.replace(/\/600_gallery/g, "/gallery"));
        sendResponse({ imgs });
    }
});
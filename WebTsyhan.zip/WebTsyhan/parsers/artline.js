chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product-slider .product-slider__view .swiper-wrapper .swiper-slide img'))
            .map(el => el.src.replace(/(?<=\/)\d*_(?=gallery_)/g, ''));
        sendResponse({ imgs });
    }
});
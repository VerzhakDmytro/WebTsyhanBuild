chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('script[type="application/ld+json"]'))
            .map(el => JSON.parse(el.textContent))
            .filter(el => el["@type"] === "Product")[0]
            .image.map(el => el.replace(/\/c_pad.*f_auto/g, ''));
        sendResponse({ imgs });
    }
});
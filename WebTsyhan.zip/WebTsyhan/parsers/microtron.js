chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product_page_grid .product_page_sliders_block .slider_full .slider_full_slider.product_slider .slick-track .slider_full_elem a'))
            .map(el => el.href);
        sendResponse({ imgs });
    }
});
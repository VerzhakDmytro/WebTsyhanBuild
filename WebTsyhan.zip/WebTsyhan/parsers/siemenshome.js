chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('[data-testid="product-gallery-gallery"] .swiper .swiper-wrapper .swiper-slide img'))
            .map(el => el.src.replace(/\/Product_Shots\/\d*x\//g, '/Product_Shots/'));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product__gallery.active .product__gallery_images .swiper-wrapper .swiper-slide:not(.swiper-slide-duplicate) img'))
            .map(el => new URL(el.dataset.src, document.baseURI).href);
        sendResponse({ imgs });
    }
});
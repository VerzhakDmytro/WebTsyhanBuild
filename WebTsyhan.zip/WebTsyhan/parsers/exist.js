chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll("[class^=Productstyle__ProductInfoWrapper] [class^=ProductGallerystyle__ProductGalleryBlock] [class^=ProductSliderstyle__ProductImage] [class^=ProductSliderstyle__ProductImageInner] [class^=Carouselstyle__CarouselWrapper]  [class^=Carouselstyle__CarouselItem] img"))
            .map(el => el.src).filter(el => !el.startsWith('https://i.ytimg.com/'));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product-detail .form-container .row .product-image-group .product-gallery__thumb .thumb-item img'))
            .map(el => el.src.replace(/\/cache\/small\//g, '/cache/original/')
        );
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('[class^=ProductSlider-module__container] .full-height img:not([class*=ProductSlider-module__imageVideo])')).map(el => el.src.replace(/imgcache\/size_.*?\//g, ''));
        sendResponse({ imgs });
    }
});
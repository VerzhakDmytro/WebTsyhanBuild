chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.leftCol .celwidget > script'))
            .filter(el => el.textContent.slice(0, 50).startsWith(`\nP.when('A').register("ImageBlockATF",`))[0]
            .textContent.match(/(?<="hiRes":").*?(?=")/g)
            .map(el => el.replace(/_SL1500_/g, '_SL5000_'));
        sendResponse({ imgs });
    }
});
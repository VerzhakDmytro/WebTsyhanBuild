chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.product a.prod-photo.gallery')).map(el => el.href);
        sendResponse({ imgs });
    }
});
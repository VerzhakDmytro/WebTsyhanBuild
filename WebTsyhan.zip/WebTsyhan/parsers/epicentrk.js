chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".swiper.swiper-initialized.swiper-horizontal:not(.swiper-thumbs):not(.swiper-grid) div.swiper-wrapper .swiper-slide div.swiper-zoom-container img")).map(el => el.src);
        sendResponse({ imgs });
    }
});
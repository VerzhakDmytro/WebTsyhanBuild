chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.container-fluid .product-slider .owl-carousel .owl-stage-outer .owl-stage .owl-item:not(.cloned) img'))
            .map(el => el.src.replace(/-\d*x\d*(?=\.)/g, ''));
        sendResponse({ imgs });
    }
});
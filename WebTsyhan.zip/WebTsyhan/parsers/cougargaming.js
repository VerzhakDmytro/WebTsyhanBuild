chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            new Set(
                Array.from(
                    Array.from(
                        document.querySelectorAll('.elementor-widget-wrap .elementor-element.elementor-widget-shortcode'))
                        .reverse()
                        .sort((a, b) => {
                            let aV = window.getComputedStyle(a).getPropertyValue("z-index");
                            let bV = window.getComputedStyle(b).getPropertyValue("z-index");
                            return bV - aV;
                        })[0]
                        .querySelectorAll('.MagicToolboxSelectorsContainer .mcs-wrapper .mcs-items-container img'))
                        .map(el => el.src)))
                        .map(el => el.replace(/-80x80./g, '.'));
        sendResponse({ imgs });
    }
});
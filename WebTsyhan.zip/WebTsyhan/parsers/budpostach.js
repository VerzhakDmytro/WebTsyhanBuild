chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            const imgs = Array.from(
                document.querySelectorAll(".product-wrap .product-page__image .product-page__image-main .swiper-wrapper img.product-page__image-main__image"))
                .map(el => el.src.replace(/(\/image\/cache\/catalog(?=\/image))|(\/cache(?=\/))|(-1200x1200(?=\.))/g, ''));

            const linkPromises = imgs.map(link => new Promise((resolve) => {
                const origExt = '.webp';
                const exts = ['.png', '.jpeg', '.jpg'];
                const extPromises = exts.map(ext => new Promise(async (resolve, reject) => {
                    const reg = new RegExp(String.raw`${origExt}`, "g");
                    const testLink = link.replace(reg, ext);
                    const res = await fetch(testLink, { method: 'HEAD' });
                    if (res.status !== 200) {
                        reject();
                    } else {
                        resolve(testLink);
                    }
                }));
                Promise.any(extPromises).then(validLink => resolve(validLink));
            }));
            Promise.all(linkPromises).then(validLinks => sendResponse({ imgs: validLinks }));
        }
    })();
    return true;
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".product-wrap .product-page__image .product-page__image-main .swiper-wrapper img.product-page__image-main__image")).map(el => el.src);
        sendResponse({ imgs });
    }
});
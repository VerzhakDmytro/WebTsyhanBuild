chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            let imgs = Array.from(
                document.querySelectorAll(".product-wrap .product-page__image .product-page__image-main .swiper-wrapper img.product-page__image-main__image"))
                .map(el => el.src.replace(/(\/image\/cache\/catalog(?=\/image))|(\/cache(?=\/))|(-1200x1200(?=\.))/g, '')
                    .replace(/\.webp/g, '.jpg'));

            for (let i = 0; i < imgs.length; i++) {
                const res = await fetch(imgs[i]);
                if (res.status !== 200) {
                    imgs[i] = imgs[i].replace(/\.jpg/g, '.png');
                }
            };
            sendResponse({ imgs });
        }
    })();
    return true;
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.cn-product-images-slider .cn-product-images-slider__preview .swiper-container .swiper-wrapper .swiper-slide:not(.swiper-slide-duplicate) img')).map(el => el.src);
        sendResponse({ imgs });
    }
});
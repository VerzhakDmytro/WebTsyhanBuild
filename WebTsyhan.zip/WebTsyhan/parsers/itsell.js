chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".product-preview-slider-top a"))
            .filter((el) => !el.classList.contains('youtube-element') && el.computedStyleMap().get('display').value !== 'none')
            .map((el) => el.href);
        sendResponse({ imgs });
    }
});
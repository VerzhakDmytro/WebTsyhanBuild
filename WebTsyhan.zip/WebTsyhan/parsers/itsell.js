let currentColorNode = null;

window.onload = (ev) => {
    Array.from(document.querySelectorAll('.product-colors-block.product-colors-block-top > div')).forEach(el => el.onmouseenter = () => {
        if (currentColorNode !== el) {
            currentColorNode = el;
            url = '';
        }
    });
    document.querySelector('.product-show-all-photos').onclick = () => {
        currentColorNode = null;
        url = '';
    }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".product-preview-slider-top a"))
            .filter((el) => !el.classList.contains('youtube-element') && el.computedStyleMap().get('display').value !== 'none')
            .map((el) => el.href);
        sendResponse({ imgs });
    }
});
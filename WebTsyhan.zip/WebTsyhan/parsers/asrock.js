chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        let imgs = Array.from(document.querySelectorAll("#briefGallery img")).map((el) => el.src.replace(/\(S/g, "(L"));
        if (imgs.length === 0) {
            imgs = Array.from(document.querySelectorAll("#Gallery #grid a")).map((el) => el.href);
        }
        sendResponse({ imgs });
    }
});
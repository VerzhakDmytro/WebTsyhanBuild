chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll("#briefGallery img")).map((el) => el.src.replace(/\(S/g, "(L"));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll("ul.product-photo__thumbs li.product-photo__thumb a.product-photo__thumb-item")).map(el => el.href);
        sendResponse({ imgs });
    }
});
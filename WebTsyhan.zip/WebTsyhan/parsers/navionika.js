chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".fotorama__nav.fotorama__nav--thumbs .fotorama__nav__shaft .fotorama__nav__frame.fotorama__nav__frame--thumb img")).map(el => el.src);
        sendResponse({ imgs });
    }
});
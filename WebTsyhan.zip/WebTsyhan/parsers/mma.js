chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product-content__container .gallery__container .gallery__left .gallery__thumbs .swiper-wrapper .swiper-slide img'))
            .map(el => el.src.replace(/-small1/g, '-big'));
        sendResponse({ imgs });
    }
});
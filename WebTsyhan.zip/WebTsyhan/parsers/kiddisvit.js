chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".b-prod-gallery .product__slider-main .slick-list .slick-track .slick-slide > div.item:not(.item__video)"))
            .map(el => new URL(el.dataset.src, document.baseURI).href);
        sendResponse({ imgs });
    }
});
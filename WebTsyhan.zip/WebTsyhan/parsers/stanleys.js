chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('#productImages .sc-product-images-main .sc-product-images-main-swiper .swiper-wrapper .sc-product-images-slide span'))
            .map(el => el.dataset.src.replace(/(\/cache)|(-\d*x\d*(?=\.))/g, ''));
        sendResponse({ imgs });
    }
});
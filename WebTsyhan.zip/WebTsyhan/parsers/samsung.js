chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".hdd02-gallery__popup-vertical .hdd02-gallery__popup-vertical-image .image-content .zoom-image img"))
            .map(el => el.src === '' ? new URL(el.dataset.src, el.baseURI).href : el.src);
        sendResponse({ imgs });
    }
});
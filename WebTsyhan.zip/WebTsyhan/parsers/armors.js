chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = [
            ...Array.from(document.querySelectorAll(".images .big a")).map(el => el.href),
            ...Array.from(document.querySelectorAll(".thumbs ul li a:not([data-type=iframe]")).map(el => el.href)
        ].map(el => el.replace(/\/big/g, "/original"));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".product-main-block.product-image .main_images_swiper .swiper-wrapper .swiper-slide a")).map(el => el.href);
        sendResponse({ imgs });
    }
});
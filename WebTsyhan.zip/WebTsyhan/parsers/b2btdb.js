chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".product-image.product-image-zoom .product-image-gallery .owl-stage img")).map(el => el.src.replace(/\/cache.*\/600x\/.*?(?=\/)/g, ""));
        sendResponse({ imgs });
    }
});
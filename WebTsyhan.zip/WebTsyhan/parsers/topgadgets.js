chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll('.us-product-photo-main .slick-list .slick-track .us-product-slide:not(.slick-cloned) a')).map(el => el.href);
        sendResponse({ imgs });
    }
});
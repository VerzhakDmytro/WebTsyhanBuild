chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        let scripts = Array.from(document.querySelectorAll('body > script'));
        let id;
        for (let i = 0; i < scripts.length; i++) {
            if (scripts[i].textContent.startsWith('window.__ALLO__=')) {
                id = scripts[i].textContent.match(/(?<=u002F2000x2000\\u002F)[^\\]+/g)[0];
                break;
            }
        }
        const imgs = Array.from(document.querySelectorAll('.full-media-thumbnails__slider-wrapper a img.full-media-thumbnails__slider-image')).map(el => el.src.replace(/\/thumbnail\/60x72\/.*?\//g, `/image/2000x2000/${id}/`));

        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = ["test"];//Array.from(document.querySelectorAll("rz-gallery-main-thumbnail-image img")).map((el) => el.src.replace(/\/medium\//g, "/original/"));
        sendResponse({ imgs });
    }
});
window.onload = (ev) => {
    try {
        let etitBtn = document.getElementById('edit-popup-btn');
        if (etitBtn !== undefined && etitBtn !== null) {
            etitBtn.onclick = () => {
                setTimeout(() => {
                    let img = document.querySelector('.modal-content a img[title="RU"]');
                    img.src = 'https://cdn-icons-png.flaticon.com/128/1642/1642901.png';
                    img.style.width = '16px';
                    img.style.verticalAlign = 'baseline';
                }, 300);
            }
        }
    } catch {

    }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".product__about_left .product_page__slider .product_slider__gallery .product_slider__wrapper .product_slider__item:not(.product_slider__item_video) img"))
            .map(el => el.src.replace(/(\/cache)|(-600x600)/g, ''));
        sendResponse({ imgs });
    }
});
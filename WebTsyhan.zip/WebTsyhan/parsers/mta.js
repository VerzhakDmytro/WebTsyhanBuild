chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".product__about_left .product_page__slider .product_slider__thumb .product_slider__wrapper img")).map(el => el.src.replace(/(\/cache)|(-600x600)/g, ''));
        sendResponse({ imgs });
    }
});
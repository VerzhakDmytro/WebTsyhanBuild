let ruFix = false;
let tryCounter = 0;

const changeRuImg = async () => {
    if (tryCounter > 50) {
        return;
    }
    tryCounter++;
    setTimeout(() => {
        let img = document.querySelector('.modal-content a img[title="RU"]');
        if (img !== null && img !== undefined) {
            img.src = 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f92e.png';
            img.style.width = '16px';
            let img2 = img.cloneNode();
            img2.src = 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/72x72/1f437.png';
            img.parentNode.appendChild(img2);
            ruFix = true;
        } else {
            changeRuImg();
        }
    }, 50);
}

window.onload = (ev) => {
    try {
        let etitBtn = document.getElementById('edit-popup-btn');
        if (etitBtn !== undefined && etitBtn !== null) {
            etitBtn.onclick = () => {
                if (!ruFix) {
                    changeRuImg();
                }
            }
        }
    } catch {

    }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".product__about_left .product_page__slider .product_slider__gallery .product_slider__wrapper .product_slider__item:not(.product_slider__item_video) img"))
            .map(el => el.src.replace(/(\/cache)|(-600x600)/g, ''));
        sendResponse({ imgs });
    }
});
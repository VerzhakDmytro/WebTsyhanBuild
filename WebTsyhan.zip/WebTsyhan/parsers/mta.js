chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".product__about_left .product_page__slider .product_slider__gallery .product_slider__wrapper .product_slider__item:not(.product_slider__item_video) img"))
            .map(el => el.src.replace(/(\/cache)|(-600x600)/g, ''));
        sendResponse({ imgs });
    }
});
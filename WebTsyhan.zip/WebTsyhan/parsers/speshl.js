chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".product .gallery .gallery-photo .gallery-photo-inner span"))
            .map(el => new URL(el.dataset.href, document.baseURI).href);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".main-gallery-container .swiper-slider-container .swiper-wrapper img"))
            .map((el) => el.src.replace(/\/thumbs\/sauto_\d*__wm/g, ''));
        sendResponse({ imgs });
    }
});
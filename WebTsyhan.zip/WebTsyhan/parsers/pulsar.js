chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll(".product-page .product-page-slider .swiper.swiper-horizontal:not(.swiper-thumbs) .swiper-wrapper .swiper-slide img"))
            .map(el => el.src.replace(/_large/g, ""));
        sendResponse({ imgs });
    }
});
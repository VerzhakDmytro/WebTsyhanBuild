chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        if (request.action === "getImgs") {
            Array.from(document.querySelectorAll('#search h3 a > div')).forEach(el => el.dispatchEvent(new MouseEvent('mouseover', {
                'view': window,
                'bubbles': true,
                'cancelable': true
            })));
            setTimeout(() => {
                const imgs = Array.from(document.querySelectorAll("#search h3 a")).map((el) => {
                    let img = el.href.match(/(?<=&imgurl=).*(?=&imgrefurl=)/g, "");
                    if (img !== null && img[0] !== null) return decodeURIComponent(img[0]);
                    else return null;
                }).filter(el => el !== null);
                sendResponse({ imgs });
            }, 1000);
        }
    })();
    return true;
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll("#search h3 a")).map((el) => {
            let q = el.href.match(/(?<=&imgurl=).*(?=&imgrefurl=)/g, "");
            let w = q;
            if (q !== null) w = decodeURIComponent(q[0]);
            return w;
        }).filter(el => el !== null);
        sendResponse({ imgs });
    }
});
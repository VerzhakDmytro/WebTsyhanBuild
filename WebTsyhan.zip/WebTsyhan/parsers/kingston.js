chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        let imgs = Array.from(
            document.querySelectorAll('.sticky_top .c-imageCarousel .c-imageCarousel__display .c-imageCarousel__display__slide:not(.c-imageCarousel__display__slide--video) > img'))
            .map(el => el.src);
        if (imgs.length === 0) {
            imgs = Array.from(
                document.querySelectorAll(".atc-images .s-ecommerce__image img"))
                .map((el) => el.src.replace(/-lg(?=\.)/g, '-zm-lg').replace(/-tn(?=\.)/g, '-zm-lg').replace(/\.png/g, '.jpg'));
        }
        if (imgs.length === 0) {
            imgs = Array.from(
                document.querySelectorAll("section.section-gallery li.product-gallery-card a.c-productCard4__image img"))
                .map(el => el.src.replace(/-tn(?=\.)/g, '-zm-lg').replace(/\.png/g, '.jpg'));
        }
        sendResponse({ imgs });
    }
});
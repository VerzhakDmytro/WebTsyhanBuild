chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        let imgs = Array.from(
            document.querySelectorAll('.sticky_top .c-imageCarousel .c-imageCarousel__display .c-imageCarousel__display__slide:not(.c-imageCarousel__display__slide--video) > img'))
            .map(el => el.src);
        if (imgs.length === 0) {
            imgs = Array.from(document.querySelectorAll(".atc-images .s-ecommerce__image img")).map((el) => el.src);
        }
        sendResponse({ imgs });
    }
});
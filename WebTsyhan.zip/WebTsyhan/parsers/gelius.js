chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product-main__container .product-main__left-side .product-main__gallery .product-gallery__inner .product-gallery-thumbs .product-gallery-thumbs__swiper .swiper-slide .product-gallery-thumbs-slide__image img'))
            .map(el => el.src.replace(/_thumbnail(?=\.)/g, ''));
        sendResponse({ imgs });
    }
});
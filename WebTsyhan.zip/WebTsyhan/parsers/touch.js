chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".mainContainer .pictureSlider a")).map((el) => el.href);
        sendResponse({ imgs });
    }
});
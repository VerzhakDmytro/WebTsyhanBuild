chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product__section--gallery .gallery .gallery__photos .gallery__photos-list li.gallery__item img'))
            .map(el => el.src.replace(/600x600l80/g, '1000x1000l99').replace(/\.webp/g, '.jpg'));
        sendResponse({ imgs });
    }
});
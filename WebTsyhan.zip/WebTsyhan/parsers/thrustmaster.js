chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".gallery-placeholder .fotorama-item .fotorama__nav--thumbs .fotorama__nav__shaft img")).map(el => el.src);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.t4s-main-product__content .flickityt4s-viewport .flickityt4s-slider .t4s-product__media-item img'))
            .map(el => new URL(el.dataset.master, document.baseURI).href);
        sendResponse({ imgs });
    }
});
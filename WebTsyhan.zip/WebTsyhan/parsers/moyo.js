chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".product_image-wrap .product_image-gallery-wrap .swiper-wrapper img")).map(el => el.src.replace(/_main/g, "_zoom").replace(/_600/g, "_4000"));
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll("#sGallery img")).map((el) => el.src);
        sendResponse({ imgs });
    }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.elementor-widget-container .entry-images .sprotulist .sprodatu .sprodatulist .swiper-wrapper .swiper-slide img'))
            .map(el => el.src);
        sendResponse({ imgs });
    }
});
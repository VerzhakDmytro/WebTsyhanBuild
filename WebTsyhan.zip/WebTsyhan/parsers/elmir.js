chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(document.querySelectorAll(".photo-block .photo-slider .ribbon-wrapper .ribbon-items img")).map((el) => el.src.replace(/\/50\/40\//g, "/3000/2000/"));
        sendResponse({ imgs });
    }
});
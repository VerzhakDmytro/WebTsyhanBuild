chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.product__gallery-main .product__gallery-main-slider .slick-track figure'))
            .map(el => el.style["background-image"]
                .slice(4, -1)
                .replace(/"/g, "")
                .replace(/(\/cache\/webp)|(-1400x1400)/g, '')
                .replace(/\.webp/g, '.jpg'));
        sendResponse({ imgs });
    }
});
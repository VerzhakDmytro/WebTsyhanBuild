chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getImgs") {
        const imgs = Array.from(
            document.querySelectorAll('.prod-block .prod-img .prod-img-slider-big ul.glide__slides .prod-img-slider-big-item:not(.glide__slide--clone) img'))
            .map(el => el.src);
        sendResponse({ imgs });
    }
});